import 'dart:html' as html;
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:hamkoroffline/cars/item.dart';
import 'package:intl/intl.dart';
import 'package:uuid/uuid.dart';

class AddItemPage extends StatefulWidget {
  @override
  _AddItemPageState createState() => _AddItemPageState();
}

class _AddItemPageState extends State<AddItemPage> {
  final DatabaseReference _itemsRef = FirebaseDatabase.instance.ref().child('items');
  final FirebaseStorage _storage = FirebaseStorage.instance;
  final _formKey = GlobalKey<FormState>();

  String _name = '';
  String _description = '';
  String _fuelType = '';
  String _year = '';
  String _enginePower = '';
  String _type = 'Avtotransport';
  double _price = 0.0;
  String _selectedCurrency = 'UZS'; // Default currency is UZS

  List<Uint8List?> _imageDataList = [];
  List<String?> _imageNamesList = [];

  List<Item> _items = []; // List to hold existing items

  @override
  void initState() {
    super.initState();
    _fetchItems(); // Fetch existing items
  }

  void _fetchItems() {
    _itemsRef.onValue.listen((event) {
      if (event.snapshot.exists) {
        final Map<String, dynamic>? data = Map<String, dynamic>.from(event.snapshot.value as Map? ?? {});
        final List<Item> loadedItems = [];
        data?.forEach((key, value) {
          if (value != null) {
            try {
              final item = Item.fromMap(Map<String, dynamic>.from(value), key);
              loadedItems.add(item);
            } catch (e) {
              print("Error parsing item: $e");
            }
          }
        });
        setState(() {
          _items = loadedItems;
        });
      }
    });
  }

  void _pickImage() {
    html.FileUploadInputElement uploadInput = html.FileUploadInputElement();
    uploadInput.accept = 'image/*';
    uploadInput.multiple = true;
    uploadInput.click();

    uploadInput.onChange.listen((e) {
      final files = uploadInput.files;
      if (files != null && files.isNotEmpty) {
        for (var file in files) {
          final reader = html.FileReader();
          reader.readAsArrayBuffer(file);

          reader.onLoadEnd.listen((e) {
            setState(() {
              _imageDataList.add(reader.result as Uint8List?);
              _imageNamesList.add(file.name);
            });
          });
        }
      }
    });
  }

  Future<List<String>> _uploadImagesToStorage() async {
    List<String> imageUrls = [];
    for (int i = 0; i < _imageDataList.length; i++) {
      if (_imageDataList[i] != null && _imageNamesList[i] != null) {
        try {
          final String fileName = Uuid().v4() + "_" + _imageNamesList[i]!;
          final Reference storageRef = _storage.ref().child('images/$fileName');
          final UploadTask uploadTask = storageRef.putData(_imageDataList[i]!);
          final TaskSnapshot downloadUrl = await uploadTask;
          final String url = await downloadUrl.ref.getDownloadURL();
          imageUrls.add(url);
        } catch (e) {
          print("Error uploading image: $e");
          return [];
        }
      }
    }
    return imageUrls;
  }

  void _submitForm() async {
    if (_formKey.currentState?.validate() ?? false) {
      _formKey.currentState?.save();

      List<String> imageUrls = await _uploadImagesToStorage();
      if (imageUrls.isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to upload images')),
        );
        return;
      }

      final id = Uuid().v4();
      try {
        await _itemsRef.child(id).set({
          'name': _name,
          'description': _description,
          'imagePaths': imageUrls,
          'fuelType': _fuelType,
          'year': _year,
          'enginePower': _enginePower,
          'type': _type,
          'price': _price,
          'currency': _selectedCurrency, // Save selected currency
        });
        _fetchItems(); // Refresh the items list
        Navigator.of(context).pop();
      } catch (e) {
        print("Error saving item to database: $e");
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to add item')),
        );
      }
    }
  }

  void _removeImage(int index) {
    setState(() {
      _imageDataList.removeAt(index);
      _imageNamesList.removeAt(index);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Mahsulot qo\'shish'),
        backgroundColor: Colors.green.shade800,
        elevation: 2,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              'Yangi Mahsulot Qo\'shish',
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.bold,
                color: Colors.green.shade800,
              ),
            ),
            SizedBox(height: 20),
            _buildForm(),
            SizedBox(height: 40),
            Text(
              'Mavjud Mahsulotlar',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Colors.green.shade800,
              ),
            ),
            SizedBox(height: 20),
            _buildItemList(),
          ],
        ),
      ),
    );
  }

  Widget _buildForm() {
    return Form(
      key: _formKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _buildTextField(
            label: 'Nomi',
            onSaved: (value) => _name = value!,
            validator: (value) => value!.isEmpty ? 'Iltimos, nomini kiriting' : null,
          ),
          SizedBox(height: 16),
          _buildTextField(
            label: 'Tavsif',
            onSaved: (value) => _description = value!,
            validator: (value) => value!.isEmpty ? 'Iltimos, tavsifni kiriting' : null,
            maxLines: 3,
          ),
          SizedBox(height: 16),
          _buildTextField(
            label: 'Yoqilg\'i turi',
            onSaved: (value) => _fuelType = value!,
            validator: (value) => value!.isEmpty ? 'Iltimos, yoqilg\'i turini kiriting' : null,
          ),
          SizedBox(height: 16),
          _buildTextField(
            label: 'Yil',
            onSaved: (value) => _year = value!,
            validator: (value) => value!.isEmpty ? 'Iltimos, yilini kiriting' : null,
          ),
          SizedBox(height: 16),
          _buildTextField(
            label: 'Dvigatel quvvati',
            onSaved: (value) => _enginePower = value!,
            validator: (value) => value!.isEmpty ? 'Iltimos, dvigatel quvvatini kiriting' : null,
          ),
          SizedBox(height: 16),
          _buildCurrencyDropdown(), // Currency dropdown
          SizedBox(height: 16),
          _buildTextField(
            label: 'Narxi',
            onSaved: (value) => _price = double.tryParse(value!) ?? 0.0,
            validator: (value) => value!.isEmpty ? 'Iltimos, narxini kiriting' : null,
            keyboardType: TextInputType.number,
          ),
          SizedBox(height: 16),
          DropdownButtonFormField<String>(
            value: _type,
            decoration: InputDecoration(
              labelText: 'Turi',
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12.0),
                borderSide: BorderSide.none,
              ),
              filled: true,
              fillColor: Colors.grey[200],
            ),
            items: [
              'Avtotransport',
              'Maxsus Texnikalar',
              'Qishloq Xo\'jaligi',
              'Bino-inshootlar',
              'Uskunalar',
            ].map((type) {
              return DropdownMenuItem(
                value: type,
                child: Text(type),
              );
            }).toList(),
            onChanged: (value) {
              setState(() {
                _type = value!;
              });
            },
            validator: (value) => value == null ? 'Iltimos, turini tanlang' : null,
          ),
          SizedBox(height: 20),
          _buildImagePicker(),
          SizedBox(height: 20),
          ElevatedButton(
            onPressed: _submitForm,
            child: Text('Mahsulot qo\'shish'),
            style: ElevatedButton.styleFrom(
              padding: EdgeInsets.symmetric(vertical: 16),
              textStyle: TextStyle(fontSize: 18),
              backgroundColor: Colors.green.shade800,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTextField({
    required String label,
    required FormFieldSetter<String> onSaved,
    required FormFieldValidator<String> validator,
    int maxLines = 1,
    TextInputType keyboardType = TextInputType.text,
  }) {
    return TextFormField(
      decoration: InputDecoration(
        labelText: label,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12.0),
          borderSide: BorderSide.none,
        ),
        filled: true,
        fillColor: Colors.grey[200],
      ),
      maxLines: maxLines,
      keyboardType: keyboardType,
      validator: validator,
      onSaved: onSaved,
    );
  }

  Widget _buildCurrencyDropdown() {
    return DropdownButtonFormField<String>(
      value: _selectedCurrency,
      decoration: InputDecoration(
        labelText: 'Valyuta',
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12.0),
          borderSide: BorderSide.none,
        ),
        filled: true,
        fillColor: Colors.grey[200],
      ),
      items: ['UZS', '\$'].map((currency) {
        return DropdownMenuItem(
          value: currency,
          child: Text(currency),
        );
      }).toList(),
      onChanged: (value) {
        setState(() {
          _selectedCurrency = value!;
        });
      },
      validator: (value) => value == null ? 'Iltimos, valyutani tanlang' : null,
    );
  }

  Widget _buildImagePicker() {
    return Column(
      children: [
        _imageDataList.isEmpty
            ? TextButton.icon(
          icon: Icon(Icons.photo_camera, color: Colors.green.shade800),
          label: Text('Rasm yuklash', style: TextStyle(color: Colors.green.shade800)),
          onPressed: _pickImage,
        )
            : Column(
          children: _imageDataList.asMap().entries.map((entry) {
            int index = entry.key;
            Uint8List? imageData = entry.value;
            return Stack(
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8.0),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(12),
                    child: Image.memory(
                      imageData!,
                      height: 150,
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
                Positioned(
                  right: 0,
                  child: IconButton(
                    icon: Icon(Icons.delete, color: Colors.red),
                    onPressed: () => _removeImage(index),
                  ),
                ),
              ],
            );
          }).toList(),
        ),
        SizedBox(height: 10),
        TextButton.icon(
          icon: Icon(Icons.photo_camera, color: Colors.green.shade800),
          label: Text('Rasm qo\'shish', style: TextStyle(color: Colors.green.shade800)),
          onPressed: _pickImage,
        ),
      ],
    );
  }

  Widget _buildItemList() {
    return ListView.builder(
      shrinkWrap: true,
      physics: NeverScrollableScrollPhysics(),
      itemCount: _items.length,
      itemBuilder: (context, index) {
        final item = _items[index];

        // Create a NumberFormat based on the item's currency
        final NumberFormat currencyFormat = NumberFormat.currency(
          locale: 'uz_UZ',
          symbol: item.currency == 'UZS' ? 'UZS' : '\$', // Use the item's currency
          decimalDigits: 0,
        );

        return Card(
          elevation: 4,
          margin: EdgeInsets.symmetric(vertical: 8),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          child: ListTile(
            leading: ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Image.network(
                item.imagePaths.isNotEmpty ? item.imagePaths[0] : '',
                width: 50,
                fit: BoxFit.cover,
                errorBuilder: (context, error, stackTrace) {
                  return Icon(Icons.broken_image, size: 50, color: Colors.grey);
                },
              ),
            ),
            title: Text(item.name),
            subtitle: Text(currencyFormat.format(item.price)), // Display formatted price with currency
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton(
                  icon: Icon(Icons.edit, color: Colors.blue),
                  onPressed: () => _editItem(item),
                ),
                IconButton(
                  icon: Icon(Icons.delete, color: Colors.red),
                  onPressed: () => _deleteItem(item.id, item.imagePaths),
                ),
              ],
            ),
          ),
        );
      },
    );
  }


  void _editItem(Item item) {
    setState(() {
      _name = item.name;
      _description = item.description;
      _fuelType = item.fuelType;
      _year = item.year;
      _enginePower = item.enginePower;
      _type = item.type;
      _price = item.price;
      _selectedCurrency = item.currency ?? 'UZS'; // Load currency
      _imageDataList = [];
      _imageNamesList = [];
    });

    _submitForm(); // Resubmit the form after editing
  }

  void _deleteItem(String id, List<String> imageUrls) async {
    try {
      await _itemsRef.child(id).remove();
      for (String imageUrl in imageUrls) {
        final Reference storageRef = _storage.refFromURL(imageUrl);
        await storageRef.delete();
      }
      _fetchItems(); // Refresh the items list
    } catch (e) {
      print("Error deleting item: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to delete item')),
      );
    }
  }
}
