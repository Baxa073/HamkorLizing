  import 'package:flutter/material.dart';
  import 'package:firebase_database/firebase_database.dart';
  import 'package:firebase_auth/firebase_auth.dart';
  import 'package:hamkoroffline/cars/AllProductsPage.dart';
  import 'package:lottie/lottie.dart';
  import 'package:responsive_builder/responsive_builder.dart';
  import 'package:url_launcher/url_launcher.dart';
  import '../Login/login_screen.dart';
  import '../dashbord_page.dart';
  import '../models/branch_addresses_section.dart';
  import '../models/currency_detail_page.dart';
  import '../models/currency_service.dart';
  import '../models/faq.dart';
  import '../models/leasing_calculator.dart';
  import '../models/leasing_services_page.dart';
  import '../models/meyory_hujjat.dart';
  import '../models/nav_bar.dart';
  import '../models/scrolling_currency_rates.dart';
  import '../models/contact_us_section.dart';
  import '../models/bizning_xizmatlar.dart';
  import '../models/hamkor_kompaniyalar.dart';
  import '../Login/employee_dashboard_page.dart';
  import '../Login/super_admin.dart';
  import '../models/home_page_slider.dart';

  class HomePage extends StatefulWidget {
    @override
    _HomePageState createState() => _HomePageState();
  }

  class _HomePageState extends State<HomePage> with SingleTickerProviderStateMixin {
    late Future<List<CurrencyRate>> futureRates;
    late AnimationController _controller;
    late Animation<Offset> _slideAnimation;
    late Animation<double> _opacityAnimation;

    GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

    // Yangi o'zgaruvchilar
    bool _isChatOpen = false; // Chat oynasi ochilganligini tekshirish uchun

    @override
    void initState() {
      super.initState();

      futureRates = CurrencyService().fetchCurrencyRates();

      _controller = AnimationController(
        duration: const Duration(seconds: 1),
        vsync: this,
      );

      _slideAnimation = Tween<Offset>(
        begin: Offset(0.0, 0.2),
        end: Offset.zero,
      ).animate(CurvedAnimation(
        parent: _controller,
        curve: Curves.easeInOut,
      ));

      _opacityAnimation = Tween<double>(
        begin: 0.0,
        end: 1.0,
      ).animate(CurvedAnimation(
        parent: _controller,
        curve: Curves.easeInOut,
      ));

      _controller.forward();
    }

    @override
    void dispose() {
      _controller.dispose();
      super.dispose();
    }

    @override
    Widget build(BuildContext context) {
      return Scaffold(
        key: _scaffoldKey,
        appBar: CustomNavBar(
          onDrawerIconPressed: () {
            _scaffoldKey.currentState?.openDrawer();
          },
        ),
        drawer: _buildDrawer(context),
        body: Stack(
          children: [
            HomePageBody(
              futureRates: futureRates,
              slideAnimation: _slideAnimation,
              opacityAnimation: _opacityAnimation,
            ),
            // Telegram and Phone icons in a column at the bottom-right corner
            Positioned(
              bottom: 20, // Adjust the distance from the bottom
              right: 20,  // Adjust the distance from the right
              child: Column(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  // Telegram Icon in rounded square with shadow
                  GestureDetector(
                    onTap: () async {
                      const telegramUrl = 'https://t.me/HamkorLizingBot';
                      if (await canLaunch(telegramUrl)) {
                        await launch(telegramUrl);
                      } else {
                        throw 'Could not launch $telegramUrl';
                      }
                    },
                    child: Container(
                      padding: EdgeInsets.all(15), // Padding around the icon
                      decoration: BoxDecoration(
                        color: Colors.blue, // Telegram's blue background color
                        borderRadius: BorderRadius.circular(20), // Rounded square
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.3), // Shadow color
                            spreadRadius: 2, // Spread the shadow
                            blurRadius: 6,  // Blur radius for soft shadow
                            offset: Offset(0, 4), // Shadow position (x, y)
                          ),
                        ],
                      ),
                      child: Icon(
                        Icons.telegram,
                        size: 32,  // Size of the phone icon
                        color: Colors.white, // Icon color
                      ),
                    ),
                  ),
                  SizedBox(height: 10), // Space between the icons
                  // Phone Icon in rounded square with shadow
                  GestureDetector(
                    onTap: () async {
                      const phoneUrl = 'tel:+998990443322';
                      if (await canLaunch(phoneUrl)) {
                        await launch(phoneUrl);
                      } else {
                        throw 'Could not launch $phoneUrl';
                      }
                    },
                    child: Container(
                      padding: EdgeInsets.all(15), // Padding around the icon
                      decoration: BoxDecoration(
                        color: Colors.green, // Green background color for phone icon
                        borderRadius: BorderRadius.circular(20), // Rounded square
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.3), // Shadow color
                            spreadRadius: 2, // Spread the shadow
                            blurRadius: 6,  // Blur radius for soft shadow
                            offset: Offset(0, 4), // Shadow position (x, y)
                          ),
                        ],
                      ),
                      child: Icon(
                        Icons.phone,
                        size: 32,  // Size of the phone icon
                        color: Colors.white, // Icon color
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      );
    }





    Widget _buildDrawer(BuildContext context) {
      return Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            DrawerHeader(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Color(0xFF1B5E20), Color(0xFF4CAF50)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
              ),
              child: Text(
                'Hamkor Lizing',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  shadows: [
                    Shadow(
                      blurRadius: 10.0,
                      color: Colors.black45,
                      offset: Offset(2.0, 2.0),
                    ),
                  ],
                ),
              ),
            ),
            _buildNavButton(
              context,
              title: 'Bosh sahifa',
              destination: HomePage(),
              icon: Icons.home,
            ),
            _buildNavButton(
              context,
              title: 'Barcha Mahsulotlar',
              destination: AllProductsPage(categoryTitle: 'Barcha Mahsulotlar'),
              icon: Icons.directions_car,
            ),
            _buildNavButton(
              context,
              title: 'Xizmatlar',
              destination: LeasingServicesPage(),
              icon: Icons.business_center,
            ),
            _buildNavButton(
              context,
              title: 'Lizing Kalkulyator',
              destination: LeasingOptionsPage(),
              icon: Icons.calculate,
            ),
            _buildNavButton(
              context,
              title: 'Me\'yoriy Hujjatlar',
              destination: MeyoriyHujjatlarPage(),
              icon: Icons.file_copy,
            ),
            ListTile(
              leading: Icon(Icons.telegram, color:Color(0xFF1B5E20)),
              title: Text(
                'Telegram',
                style: TextStyle(
                  color: Colors.black87,
                  fontWeight: FontWeight.w600,
                ),
              ),
              onTap: () async {
                const telegramUrl = 'https://t.me/HamkorLizingBot';
                if (await canLaunch(telegramUrl)) {
                  await launch(telegramUrl);
                } else {
                  throw 'Could not launch $telegramUrl';
                }
              },
            ),
            if (FirebaseAuth.instance.currentUser != null)
              FutureBuilder<Widget>(
                future: _determineDestination(),
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: CircularProgressIndicator(),
                    );
                  } else if (snapshot.hasError) {
                    return Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Text('Error: ${snapshot.error}'),
                    );
                  } else if (snapshot.hasData) {
                    return _buildNavButton(
                      context,
                      title: 'Shaxsiy Hisobim',
                      destination: snapshot.data!,
                      icon: Icons.account_circle,
                    );
                  } else {
                    return Container();
                  }
                },
              ),
            if (FirebaseAuth.instance.currentUser == null)
              _buildNavButton(
                context,
                title: 'Kirish',
                destination: LoginScreen(),
                icon: Icons.login,
              ),
          ],
        ),
      );
    }


    Future<Widget> _determineDestination() async {
      User? currentUser = FirebaseAuth.instance.currentUser;

      if (currentUser == null) {
        return LoginScreen();
      }

      String email = currentUser.email?.toLowerCase() ?? '';
      final roleRef = FirebaseDatabase.instance
          .ref()
          .child('profiles/${currentUser.uid}/role');

      final DatabaseEvent event = await roleRef.once();
      final String role = event.snapshot.value as String? ?? '';

      if (role == 'SuperAdmin' || email == 'buxorovbahodir11@gmail.com') {
        return SuperAdminProfilePage();
      } else if (role == 'Bosh Direktor') {
        return AdminDashboardPage();
      } else {
        return EmployeeDashboardPage(user: currentUser);
      }
    }

    Widget _buildNavButton(BuildContext context,
        {required String title, required Widget destination, required IconData icon}) {
      return ListTile(
        leading: Icon(icon, color: Color(0xFF1B5E20)),
        title: Text(
          title,
          style: TextStyle(
            color: Colors.black87,
            fontWeight: FontWeight.w600,
          ),
        ),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => destination),
          );
        },
      );
    }
  }

  class HomePageBody extends StatelessWidget {
    final Future<List<CurrencyRate>> futureRates;
    final Animation<Offset> slideAnimation;
    final Animation<double> opacityAnimation;

    const HomePageBody({
      Key? key,
      required this.futureRates,
      required this.slideAnimation,
      required this.opacityAnimation,
    }) : super(key: key);

    @override
    Widget build(BuildContext context) {
      return ResponsiveBuilder(
        builder: (context, sizingInformation) {
          bool isMobile = sizingInformation.isMobile;
          double fontSizeMultiplier = isMobile ? 0.9 : 1.1;

          return Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Colors.white, Colors.grey.shade200],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  _buildLeasingInfoSection(fontSizeMultiplier),
                  SizedBox(height: 30),
                  _buildHamkorLizingSection(fontSizeMultiplier),
                  SizedBox(height: 30),
                  _buildIjaraSection(fontSizeMultiplier),
                  SizedBox(height: 30),
                  BizningXizmatlarimizSection(
                    fontSizeMultiplier: fontSizeMultiplier,
                    slideAnimation: slideAnimation,
                    opacityAnimation: opacityAnimation,
                  ),
                  SizedBox(height: 30),
                  BranchAddressesSection(
                    fontSizeMultiplier: fontSizeMultiplier,
                  ),
                  SizedBox(height: 30),
                  HamkorKompaniyalarSection(),
                  SizedBox(height: 30),
                  FAQSection(),
                  SizedBox(height: 30),
                  ContactUsSection(
                    fontSizeMultiplier: fontSizeMultiplier,
                    slideAnimation: slideAnimation,
                    opacityAnimation: opacityAnimation,
                  ),
                  SizedBox(height: 30),
                ],
              ),
            ),
          );
        },
      );
    }

    Widget _buildLeasingInfoSection(double fontSizeMultiplier) {
      return Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20.0),
        child: ResponsiveBuilder(
          builder: (context, sizingInformation) {
            bool isMobile = sizingInformation.isMobile;

            return Column(
              children: [
                HomePageSlider(),
                SizedBox(height: 30),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      flex: 2,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Image.asset(
                            'assets/images/Logo__1.png',
                            height: 100 * fontSizeMultiplier,
                            fit: BoxFit.contain,
                            alignment: Alignment.center,
                          ),
                          SizedBox(height: 20),
                          Text(
                            'Biznesingiz rivoji uchun yangi imkoniyatlarni oching. Hamkor Lizing — moliyaviy yechimlar va ko\'mak orqali biznesingizni yangi cho\'qqilarga olib chiqadi. Biz bilan kelajakka qadam qo\'ying, moliyaviy erkinlik va muvaffaqiyatga yo\'l oching.',
                            style: TextStyle(
                              color: Color(0xFF1B5E20),
                              fontSize: 20 * fontSizeMultiplier,
                              height: 1.5,
                              shadows: [
                                Shadow(
                                  blurRadius: 5.0,
                                  color: Colors.black12,
                                  offset: Offset(2.0, 2.0),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    if (!isMobile)
                      Expanded(
                        flex: 1,
                        child: Lottie.asset(
                          'assets/animations/p1.json',
                          width: 500,
                          height: 500,
                          fit: BoxFit.contain,
                        ),
                      ),
                  ],
                ),
                if (isMobile) SizedBox(height: 20),
                if (isMobile)
                  Lottie.asset(
                    'assets/animations/p1.json',
                    width: 300,
                    height: 300,
                    fit: BoxFit.contain,
                  ),
              ],
            );
          },
        ),
      );
    }

    Widget _buildHamkorLizingSection(double fontSizeMultiplier) {
      return Padding(
        padding: const EdgeInsets.all(20.0),
        child: ResponsiveBuilder(
          builder: (context, sizingInformation) {
            bool isMobile = sizingInformation.isMobile;

            return Column(
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      flex: 1,
                      child: SlideTransition(
                        position: slideAnimation,
                        child: FadeTransition(
                          opacity: opacityAnimation,
                          child: Container(
                            padding: EdgeInsets.all(20.0),
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [Color(0xFFD7ECCC), Color(0xFFAED581)],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              ),
                              borderRadius: BorderRadius.circular(20),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black12,
                                  spreadRadius: 3,
                                  blurRadius: 10,
                                  offset: Offset(0, 3),
                                ),
                              ],
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Icon(
                                      Icons.show_chart,
                                      color: Color(0xFF1B5E20),
                                      size: isMobile ? 40 : 80,
                                    ),
                                    SizedBox(width: 10),
                                    Expanded(
                                      child: Text(
                                        'Lizing nima va u qanday ishlaydi?',
                                        style: TextStyle(
                                          fontSize: isMobile ? 20 : 36,
                                          fontWeight: FontWeight.bold,
                                          color: Colors.black87,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(height: 20),
                                Text(
                                  'Lizing — bu moliyaviy ijaraning o\'ziga xos turi bo\'lib, unda lizing beruvchi kompaniya mijozning talabiga ko\'ra mol-mulkni sotib olib, uzoq muddatli ijaraga beradi. Lizing oluvchi esa, bu mol-mulkdan foydalanish orqali daromad oladi yoki biznesini rivojlantiradi. Muddati oxirida esa lizing oluvchi, mol-mulkni o\'z nomiga o\'tkazish imkoniyatiga ega bo\'ladi.',
                                  style: TextStyle(
                                    fontSize: isMobile ? 16 : 24,
                                    color: Colors.black87,
                                    height: 1.5,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                    if (!isMobile) SizedBox(width: 20),
                    if (!isMobile)
                      Expanded(
                        flex: 1,
                        child: SlideTransition(
                          position: slideAnimation,
                          child: FadeTransition(
                            opacity: opacityAnimation,
                            child: Lottie.asset(
                              'assets/animations/p2.json',
                              width: 500,
                              height: 500,
                              fit: BoxFit.contain,
                            ),
                          ),
                        ),
                      ),
                  ],
                ),
                if (isMobile) SizedBox(height: 20),
                if (isMobile)
                  Lottie.asset(
                    'assets/animations/p2.json',
                    width: 300,
                    height: 300,
                    fit: BoxFit.contain,
                  ),
              ],
            );
          },
        ),
      );
    }

    Widget _buildIjaraSection(double fontSizeMultiplier) {
      return Padding(
        padding: const EdgeInsets.all(20.0),
        child: ResponsiveBuilder(
          builder: (context, sizingInformation) {
            bool isMobile = sizingInformation.isMobile;

            return Column(
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    if (!isMobile)
                      Expanded(
                        flex: 1,
                        child: Lottie.asset(
                          'assets/animations/ijara.json',
                          width: 300,
                          height: 300,
                          fit: BoxFit.contain,
                        ),
                      ),
                    if (!isMobile) SizedBox(width: 20),
                    Expanded(
                      flex: 2,
                      child: Container(
                        padding: EdgeInsets.all(20.0),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [Color(0xFFF1F8E9), Color(0xFF81C784)],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                          borderRadius: BorderRadius.circular(20),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black26,
                              spreadRadius: 2,
                              blurRadius: 8,
                              offset: Offset(2, 4),
                            ),
                          ],
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Ijara Turlari',
                              style: TextStyle(
                                fontSize: isMobile ? 20 : 36,
                                fontWeight: FontWeight.bold,
                                color: Colors.black87,
                              ),
                            ),
                            SizedBox(height: 10),
                            Text(
                              'Ijara faoliyati – kelishuvga binoan bir tomon (ijaraga beruvchi) boshqa tomonga (ijaraga oluvchiga) haq evaziga vaqtinchalik egalik qilish va foydalanish yoki kelishilgan muddat davomida mulkdan foydalanish huquqini berish yuzasidan faoliyat.',
                              style: TextStyle(
                                fontSize: isMobile ? 14 : 20,
                                color: Colors.black87,
                                height: 1.5,
                              ),
                            ),
                            SizedBox(height: 10),
                            Text(
                              'Moliyaviy ijara - mulkni (moliyaviy ijara obyektini) shartnomaga binoan 12 (Oʻn ikki) oydan ortiq muddatga egalik qilish va foydalanish xuquqini berish, tuzilgan moliyaviy ijara shartnomasi yakunida ijara obyektini ijaraga oluvchiga mulk xuquqi asosida rasmiylashtirib berilishi jarayonida yuzaga keladigan ijaraviy munosabatlar.',
                              style: TextStyle(
                                fontSize: isMobile ? 14 : 20,
                                color: Colors.black87,
                                height: 1.5,
                              ),
                            ),
                            SizedBox(height: 10),
                            Text(
                              'Operativ ijara – bu moliyaviy ijara shartnomasi xisoblanmaydigan mulk ijara shartnomasiga muvofiq mulkni vaqtinchalik egalik qilish yoki foydalanishga berilishi boʻyicha ijara munosabatlari.',
                              style: TextStyle(
                                fontSize: isMobile ? 14 : 20,
                                color: Colors.black87,
                                height: 1.5,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
                if (isMobile) SizedBox(height: 20),
                if (isMobile)
                  Lottie.asset(
                    'assets/animations/ijara.json',
                    width: 300,
                    height: 300,
                    fit: BoxFit.contain,
                  ),
              ],
            );
          },
        ),
      );
    }
  }
