import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class HamkorKompaniyalarSection extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final List<Map<String, String>> companies = [
      {'logo': 'assets/logo/ChinaMotors.png', 'url': 'https://chinamotors.uz/'},
      {'logo': 'assets/logo/Howo.png', 'url': 'https://www.howocentre.uz/'},
      {'logo': 'assets/logo/Planeta.png', 'url': 'https://www.prom.uz/company/chp-planeta-servis/'},
      {'logo': 'assets/logo/road.png', 'url': 'https://autoline.uz/roadstartrans/'},
      {'logo': 'assets/logo/zulya.jpg', 'url': 'https://t.me/spetstexnika_zulya'},
      {'logo': 'assets/logo/Sn.png', 'url': 'https://sninvest.uz/'},
      {'logo': 'assets/logo/Tas.png', 'url': 'https://tasuz.com/'},
      {'logo': 'assets/logo/TraktorBor.png', 'url': 'https://traktorbor.uz/uz/'},
      {'logo': 'assets/logo/Uzcase.png', 'url': 'https://agrobaza.uz/ru/showcase/uzcasemash-84/'},
    ];

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 40.0),
      child: Column(
        children: [
          Center(
            child: Text(
              'Bizning Hamkor Kompaniyalar',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
              textAlign: TextAlign.center,
            ),
          ),
          SizedBox(height: 20),
          CarouselSlider(
            options: CarouselOptions(
              height: 150,  // Adjust height to make logos bigger
              autoPlay: true,
              autoPlayInterval: Duration(milliseconds: 1000),  // Very short delay between slides
              autoPlayAnimationDuration: Duration(milliseconds: 3000),  // Speed of sliding, adjusted to 5 seconds
              viewportFraction: 0.3,  // Adjust to fit more logos in the view
              enableInfiniteScroll: true,
              autoPlayCurve: Curves.linear,  // Smooth linear scroll
              scrollDirection: Axis.horizontal,
              pauseAutoPlayOnTouch: false,  // Don't stop when touched
              pauseAutoPlayOnManualNavigate: false,  // Don't stop on manual swipe
            ),
            items: companies.map((company) {
              return GestureDetector(
                onTap: () {
                  _launchURL(company['url']!);
                },
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 10.0),
                  child: Image.asset(
                    company['logo']!,
                    height: 100,  // Increase size if necessary
                    fit: BoxFit.contain,
                  ),
                ),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }

  void _launchURL(String url) async {
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      throw 'Could not launch $url';
    }
  }
}
