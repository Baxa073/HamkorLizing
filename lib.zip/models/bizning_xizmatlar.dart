import 'package:flutter/material.dart';
import 'package:responsive_builder/responsive_builder.dart';

class BizningXizmatlarimizSection extends StatelessWidget {
  final double fontSizeMultiplier;
  final Animation<Offset> slideAnimation;
  final Animation<double> opacityAnimation;

  const BizningXizmatlarimizSection({
    required this.fontSizeMultiplier,
    required this.slideAnimation,
    required this.opacityAnimation,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(
        vertical: 20.0,
        horizontal: getValueForScreenType<double>(
          context: context,
          mobile: 10.0,
          tablet: 15.0,
          desktop: 20.0,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildAnimatedTitle(),
          SizedBox(height: 10),
          _buildDescription(),
          SizedBox(height: 30),
          ResponsiveBuilder(
            builder: (context, sizingInformation) {
              bool isMobile = sizingInformation.isMobile;
              return isMobile ? _buildMobileView() : _buildDesktopView();
            },
          ),
        ],
      ),
    );
  }

  Widget _buildAnimatedTitle() {
    return SlideTransition(
      position: slideAnimation,
      child: FadeTransition(
        opacity: opacityAnimation,
        child: Text(
          'Bizning xizmatlarimiz',
          style: TextStyle(
            color: Colors.green[900],
            fontSize: 36.0 * fontSizeMultiplier,
            fontWeight: FontWeight.bold,
            shadows: [
              Shadow(
                blurRadius: 10.0,
                color: Colors.grey.withOpacity(0.5),
                offset: Offset(3.0, 3.0),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDescription() {
    return SlideTransition(
      position: slideAnimation,
      child: FadeTransition(
        opacity: opacityAnimation,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 1.0),
          child: ConstrainedBox(
            constraints: BoxConstraints(maxWidth: 1200),
            child: Text(
              'Sizning biznesingizni rivojlantirish uchun taqdim etayotgan lizing xizmatlarimiz bilan tanishing. Bizning yechimlarimiz sizga yangi aktivlar olish, moliyaviy imkoniyatlarni kengaytirish va biznesingizni yanada barqaror qilish imkoniyatini taqdim etadi. Har bir xizmat haqida ko\'proq ma\'lumot olish uchun quyidagi bo\'limlardan birini tanlang.',
              style: TextStyle(
                color: Colors.black87,
                fontSize: 25.0 * fontSizeMultiplier,
                height: 1.4,
                shadows: [
                  Shadow(
                    blurRadius: 5.0,
                    color: Colors.grey.withOpacity(0.2),
                    offset: Offset(2.0, 2.0),
                  ),
                ],
              ),
              textAlign: TextAlign.justify,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildMobileView() {
    return Column(
      children: [
        _buildAnimatedServiceCard(
          icon: Icons.apps,
          title: 'LIZING MODELI',
          description:
          'Lizing — bu moliyaviy yechim bo\'lib, sizga kerakli aktivlarni (mashinalar, texnikalar, uskunalar va h.k.) olish imkonini beradi, bunda to\'liq xarajatni birdaniga to\'lash o\'rniga, uzluksiz to\'lovlar bilan foydalanish imkoniyatini taqdim etadi. Bu usul biznesingizga yangi imkoniyatlar yaratib, uning o\'sishini qo\'llab-quvvatlaydi.',
        ),
        SizedBox(height: 20),
        _buildAnimatedServiceCard(
          icon: Icons.show_chart,
          title: 'LIZINGNI AMALGA OSHIRISH',
          description:
          'Lizing orqali siz kerakli mol-mulkni tanlaysiz, biz esa uni sotib olib, sizga uzoq muddatli ijaraga beramiz. Bu bilan siz aktivlardan darhol foydalanishni boshlashingiz va to\'lovlarni uzoq muddat davomida amalga oshirishingiz mumkin. Lizing muddati tugagach, aktivlarni to\'liq egalik qilishingiz ham mumkin.',
        ),
        SizedBox(height: 20),
        _buildAnimatedServiceCard(
          icon: Icons.lightbulb_outline,
          title: 'LIZING MONITORINGI',
          description:
          'Lizing monitoringi jarayonida biz sizning aktivlaringizni doimiy ravishda kuzatib boramiz. Bu orqali siz lizing shartlarini to\'g\'ri boshqarishingiz va aktivlaringizning holatini nazorat qilishingiz mumkin. Monitoring xizmati orqali moliyaviy xavfsizlikni ta\'minlash va aktivlar samaradorligini oshirish imkoniyatiga ega bo\'lasiz.',
        ),
      ],
    );
  }

  Widget _buildDesktopView() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Expanded(
          child: _buildAnimatedServiceCard(
            icon: Icons.apps,
            title: 'LIZING MODELI',
            description:
            'Lizing — bu moliyaviy yechim bo\'lib, sizga kerakli aktivlarni (mashinalar, texnikalar, uskunalar va h.k.) olish imkonini beradi, bunda to\'liq xarajatni birdaniga to\'lash o\'rniga, uzluksiz to\'lovlar bilan foydalanish imkoniyatini taqdim etadi. Bu usul biznesingizga yangi imkoniyatlar yaratib, uning o\'sishini qo\'llab-quvvatlaydi.',
          ),
        ),
        SizedBox(width: 20),
        Expanded(
          child: _buildAnimatedServiceCard(
            icon: Icons.show_chart,
            title: 'LIZINGNI AMALGA OSHIRISH',
            description:
            'Lizing orqali siz kerakli mol-mulkni tanlaysiz, biz esa uni sotib olib, sizga uzoq muddatli ijaraga beramiz. Bu bilan siz aktivlardan darhol foydalanishni boshlashingiz va to\'lovlarni uzoq muddat davomida amalga oshirishingiz mumkin. Lizing muddati tugagach, aktivlarni to\'liq egalik qilishingiz ham mumkin.',
          ),
        ),
        SizedBox(width: 20),
        Expanded(
          child: _buildAnimatedServiceCard(
            icon: Icons.lightbulb_outline,
            title: 'LIZING MONITORINGI',
            description:
            'Lizing monitoringi jarayonida biz sizning aktivlaringizni doimiy ravishda kuzatib boramiz. Bu orqali siz lizing shartlarini to\'g\'ri boshqarishingiz va aktivlaringizning holatini nazorat qilishingiz mumkin. Monitoring xizmati orqali moliyaviy xavfsizlikni ta\'minlash va aktivlar samaradorligini oshirish imkoniyatiga ega bo\'lasiz.',
          ),
        ),
      ],
    );
  }

  Widget _buildAnimatedServiceCard({
    required IconData icon,
    required String title,
    required String description,
  }) {
    return IntrinsicHeight(
      child: SlideTransition(
        position: slideAnimation,
        child: FadeTransition(
          opacity: opacityAnimation,
          child: Container(
            padding: EdgeInsets.all(20.0),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Colors.green[700]!, Colors.green[500]!],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.2),
                  spreadRadius: 3,
                  blurRadius: 10,
                  offset: Offset(0, 3),
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(
                  icon,
                  color: Color(0xFFFFD700), // Gold accent for icons
                  size: 40.0 * fontSizeMultiplier,
                ),
                SizedBox(height: 20),
                Text(
                  title,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 25.0 * fontSizeMultiplier,
                    fontWeight: FontWeight.bold,
                    shadows: [
                      Shadow(
                        blurRadius: 5.0,
                        color: Colors.black.withOpacity(0.5),
                        offset: Offset(2.0, 2.0),
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 10),
                Expanded(
                  child: Text(
                    description,
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.9),
                      fontSize: 22.0 * fontSizeMultiplier,
                      height: 1.5,
                    ),
                    textAlign: TextAlign.justify,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
