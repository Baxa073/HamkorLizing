import 'dart:convert';
import 'package:http/http.dart' as http;

class CurrencyRate {
  final String currencyCode;
  final double cbRate;
  final double buyRate;
  final double sellRate;
  final double change;
  final bool isUp;

  CurrencyRate({
    required this.currencyCode,
    required this.cbRate,
    required this.buyRate,
    required this.sellRate,
    required this.change,
    required this.isUp,
  });

  factory CurrencyRate.fromJson(Map<String, dynamic> json) {
    double cbRate = double.parse(json['Rate']);
    double buyRate = cbRate * 0.995;
    double sellRate = cbRate * 1.005;
    double change = double.parse(json['Diff']);
    bool isUp = change > 0;

    return CurrencyRate(
      currencyCode: json['Ccy'],
      cbRate: cbRate,
      buyRate: buyRate,
      sellRate: sellRate,
      change: change,
      isUp: isUp,
    );
  }
}

class CurrencyService {
  final String apiUrl = 'https://cbu.uz/uz/arkhiv-kursov-valyut/json/';

  Future<List<CurrencyRate>> fetchCurrencyRates() async {
    try {
      final response = await http.get(Uri.parse(apiUrl));
      if (response.statusCode == 200) {
        List<dynamic> data = json.decode(response.body);
        return data.map((json) => CurrencyRate.fromJson(json)).toList();
      } else {
        throw Exception('Server returned status code: ${response.statusCode}');
      }
    } catch (error) {
      throw Exception('Failed to fetch currency rates: $error');
    }
  }
}
