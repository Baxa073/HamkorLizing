import 'package:flutter/material.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:hamkoroffline/cars/AllProductsPage.dart';
import 'package:responsive_builder/responsive_builder.dart';

class HomePageSlider extends StatelessWidget {
  final bool autoPlay;
  final Duration autoPlayInterval;
  final Duration animationDuration;

  HomePageSlider({
    this.autoPlay = true,
    this.autoPlayInterval = const Duration(seconds: 4),
    this.animationDuration = const Duration(milliseconds: 800),
  });

  final List<Map<String, String>> slidesContent = [
    {
      'imagePath': 'assets/cars/BYD.png',
      'title': 'Avtotransport',
      'subtitle': 'Eng yaxshi avtomobillar',
      'description':
      'Eng so\'nggi modellar, qulay shartlar bilan. Lizing shartlari moslashuvchan va xaridlar uchun maxsus chegirmalar mavjud.',
    },
    {
      'imagePath': 'assets/cars/maxsus.png',
      'title': 'Maxsus Texnika',
      'subtitle': 'Sanoat va Qurilish Texnikasi',
      'description':
      'Og\'ir texnikalar va maxsus texnikalarni qulay lizing shartlarida sotib oling. Tezkor yetkazib berish va maxsus chegirmalar bilan.',
    },
    {
      'imagePath': 'assets/cars/tractor.png',
      'title': 'Qishloq Xo\'jalik Texnikalari',
      'subtitle': 'Fermalar uchun eng yaxshi tanlov',
      'description':
      'Hosildorlikni oshiruvchi texnologiyalar bilan jihozlangan zamonaviy qishloq xo\'jalik texnikalari. Qulay lizing shartlari mavjud.',
    },
    {
      'imagePath': 'assets/cars/factory.png',
      'title': 'Bino-inshootlar',
      'subtitle': 'Tijorat va Sanoat Bino-Inshootlari',
      'description':
      'Qurilish va rekonstruksiya loyihalari uchun moliyaviy yechimlar. Lizing orqali binolarni qulay shartlar bilan qo\'lga kiriting.',
    },
    {
      'imagePath': 'assets/cars/uskuna.png',
      'title': 'Uskunalar',
      'subtitle': 'Sanoat va Tijorat Uskunalari',
      'description':
      'Zamonaviy uskunalar, yuqori samaradorlik bilan. Lizing orqali uskunalarni qulay shartlar bilan xarid qiling.',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return ResponsiveBuilder(
      builder: (context, sizingInformation) {
        bool isMobile = sizingInformation.isMobile;
        double aspectRatio = isMobile ? 1.5 : 2.5;

        return CarouselSlider.builder(
          options: CarouselOptions(
            aspectRatio: aspectRatio,
            enlargeCenterPage: true,
            autoPlay: autoPlay,
            autoPlayInterval: autoPlayInterval,
            autoPlayAnimationDuration: animationDuration,
            viewportFraction: isMobile ? 0.9 : 0.8,
          ),
          itemCount: slidesContent.length,
          itemBuilder: (BuildContext context, int index, int realIndex) {
            return SliderItem(
              imagePath: slidesContent[index]['imagePath']!,
              title: slidesContent[index]['title']!,
              subtitle: slidesContent[index]['subtitle']!,
              description: slidesContent[index]['description']!,
              isMobile: isMobile,
              onTap: () {
                _navigateToAllProductsPage(context, slidesContent[index]['title']!);
              },
            );
          },
        );
      },
    );
  }

  void _navigateToAllProductsPage(BuildContext context, String categoryTitle) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => AllProductsPage(
          categoryTitle: categoryTitle,
        ),
      ),
    );
  }
}

class SliderItem extends StatelessWidget {
  final String imagePath;
  final String title;
  final String subtitle;
  final String description;
  final bool isMobile;
  final VoidCallback onTap;

  const SliderItem({
    required this.imagePath,
    required this.title,
    required this.subtitle,
    required this.description,
    required this.isMobile,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: Duration(milliseconds: 500),
      margin: EdgeInsets.symmetric(horizontal: isMobile ? 5.0 : 10.0), // Reduced margin for mobile
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(isMobile ? 12.0 : 16.0), // Adjusted border radius for mobile
        gradient: LinearGradient(
          colors: [Color(0xFF1B5E20), Color(0xFF43A047)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black26,
            blurRadius: isMobile ? 6 : 10, // Reduced blur for mobile
            offset: Offset(0, isMobile ? 3 : 5), // Adjusted offset for mobile
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(isMobile ? 12.0 : 16.0), // Adjusted border radius for mobile
        child: Row(
          children: [
            Expanded(
              flex: 4,
              child: Image.asset(
                imagePath,
                fit: BoxFit.cover, // Ensures the image scales properly
                semanticLabel: title,
              ),
            ),
            Expanded(
              flex: 3,
              child: SingleChildScrollView(
                child: Container(
                  padding: EdgeInsets.all(isMobile ? 12 : 16), // Adjust padding for mobile
                  child: _buildTextContent(),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTextContent() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text(
          title,
          style: TextStyle(
            color: Colors.white,
            fontSize: isMobile ? 18 : 32, // Reduced font size for mobile
            fontWeight: FontWeight.bold,
          ),
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
        ),
        SizedBox(height: isMobile ? 8 : 10), // Adjusted spacing for mobile
        Text(
          subtitle,
          style: TextStyle(
            color: Color(0xFFFFD700),
            fontSize: isMobile ? 14 : 24, // Reduced font size for mobile
            fontWeight: FontWeight.bold,
          ),
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
        ),
        SizedBox(height: isMobile ? 8 : 10), // Adjusted spacing for mobile
        Text(
          description,
          style: TextStyle(
            color: Colors.white.withOpacity(0.9),
            fontSize: isMobile ? 12 : 20, // Reduced font size for mobile
            height: 1.4,
          ),
          maxLines: 3,
          overflow: TextOverflow.ellipsis,
        ),
        SizedBox(height: isMobile ? 16 : 20), // Adjusted spacing for mobile
        ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: Color(0xFF64DD17),
            padding: EdgeInsets.symmetric(vertical: isMobile ? 10 : 12, horizontal: isMobile ? 20 : 24), // Adjusted padding for mobile
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8),
            ),
            elevation: isMobile ? 3 : 5, // Reduced elevation for mobile
          ),
          onPressed: onTap,
          child: Text(
            'Batafsil Ma\'lumot',
            style: TextStyle(
              color: Colors.white,
              fontSize: isMobile ? 13 : 18, // Reduced font size for mobile
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ],
    );
  }
}
