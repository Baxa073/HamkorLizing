// scrolling_currency_rates.dart
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'currency_detail_page.dart';
import 'currency_service.dart';

class ScrollingCurrencyRates extends StatefulWidget {
  final List<CurrencyRate> rates;

  ScrollingCurrencyRates({required this.rates});

  @override
  _ScrollingCurrencyRatesState createState() => _ScrollingCurrencyRatesState();
}

class _ScrollingCurrencyRatesState extends State<ScrollingCurrencyRates>
    with SingleTickerProviderStateMixin {
  late ScrollController _scrollController;
  late AnimationController _animationController;

  @override
  void initState() {
    super.initState();
    _scrollController = ScrollController();
    _animationController = AnimationController(
      vsync: this,
      duration: Duration(seconds: 500), // Scroll speed
    )..repeat();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _scroll();
    });
  }

  void _scroll() {
    _scrollController
        .animateTo(
      _scrollController.position.maxScrollExtent,
      duration: _animationController.duration!,
      curve: Curves.linear,
    )
        .then((value) {
      _scrollController.jumpTo(_scrollController.position.minScrollExtent);
      _scroll();
    });
  }

  @override
  void dispose() {
    _scrollController.dispose();
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      controller: _scrollController,
      child: Row(
        children: widget.rates.map((rate) {
          return GestureDetector(
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => CurrencyDetailPage(rates: [rate])),
            ),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Row(
                    children: [
                      Image.asset(
                        'assets/flags/${rate.currencyCode}.png',
                        width: 30,
                        height: 20,
                        errorBuilder: (context, error, stackTrace) =>
                            Icon(Icons.flag),
                      ),
                      SizedBox(width: 5),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "${rate.currencyCode}",
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Text(
                            "Sotib olish: ${rate.buyRate.toStringAsFixed(2)}",
                            style: TextStyle(color: Colors.black),
                          ),
                        ],
                      ),
                    ],
                  ),
                ],
              ),
            ),
          );
        }).toList(),
      ),
    );
  }
}
