import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:flutter/services.dart';
import 'dart:math' as math;
import '../qaytarish_grafik_page.dart';
import '../ijara_grafik_page.dart';

class YengilAvtomobilLizingKalkulyatorPage extends StatefulWidget {
  @override
  _YengilAvtomobilLizingKalkulyatorPageState createState() =>
      _YengilAvtomobilLizingKalkulyatorPageState();
}

class _YengilAvtomobilLizingKalkulyatorPageState
    extends State<YengilAvtomobilLizingKalkulyatorPage> {
  final _formKey = GlobalKey<FormState>();

  final _priceController = TextEditingController(text: '0');
  final _marginController = TextEditingController(text: '30.0%');
  final _durationController = TextEditingController(text: '36');
  final _insuranceController = TextEditingController(text: '1.0%');
  final _gaiController = TextEditingController(text: '3,753,600');
  final _gpsController = TextEditingController(text: '600,000');
  final _commissionController = TextEditingController(text: '5.0%');
  final _initialPaymentController = TextEditingController(text: '30');

  String _selectedOption = 'Lizing';

  double _remainingSum = 0.0;
  double _initialPayment = 0.0;
  double _insuranceFee = 0.0;
  double _qqs = 0.0;
  double _totalLeaseAmount = 0.0;
  double _oneTimeCommission = 0.0;
  double _totalPayment = 0.0;
  List<List<dynamic>> _tableData = [];

  void _calculate() {
    if (_formKey.currentState!.validate()) {
      final double price =
          double.parse(_priceController.text.replaceAll(',', ''));
      final int duration = int.parse(_durationController.text);
      final double margin =
          double.parse(_marginController.text.replaceAll('%', '')) / 100;
      final double initialPaymentPercent =
          double.parse(_initialPaymentController.text) / 100;

      setState(() {
        _insuranceFee = (price *
                double.parse(_insuranceController.text.replaceAll('%', '')) /
                100) *
            (duration / 12);
        _qqs = (_insuranceFee +
                double.parse(_gpsController.text.replaceAll(',', '')) +
                double.parse(_gaiController.text.replaceAll(',', ''))) *
            0.12;
        _totalLeaseAmount = price +
            _qqs +
            _insuranceFee +
            double.parse(_gpsController.text.replaceAll(',', '')) +
            double.parse(_gaiController.text.replaceAll(',', ''));
        _initialPayment = _totalLeaseAmount * initialPaymentPercent;
        _oneTimeCommission = _totalLeaseAmount *
            double.parse(_commissionController.text.replaceAll('%', '')) /
            100;
        _totalPayment = _oneTimeCommission + _initialPayment;
        _remainingSum = _totalLeaseAmount - _initialPayment;

        _tableData = _calculateTableData(_remainingSum, duration, margin);

        if (_selectedOption == 'Lizing') {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => QaytarishGrafikPage(
                narxi: price,
                marja: margin,
                sugurta: _insuranceFee,
                gai: double.parse(_gaiController.text.replaceAll(',', '')),
                gps: double.parse(_gpsController.text.replaceAll(',', '')),
                qqs: _qqs,
                komissiya: _oneTimeCommission,
                muddat: duration,
                boshlangichTolov: _initialPayment,
                tableData: _tableData,
                jamiLizingSummasi: _totalLeaseAmount,
                jamiTolov: _totalPayment,
                commissionPercentage: _commissionController.text,
              ),
            ),
          );
        } else {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => IjaraGrafikPage(
                narxi: price,
                marja: margin,
                sugurta: _insuranceFee,
                gai: double.parse(_gaiController.text.replaceAll(',', '')),
                gps: double.parse(_gpsController.text.replaceAll(',', '')),
                qqs: _qqs,
                komissiya: _oneTimeCommission,
                muddat: duration,
                boshlangichTolov: _initialPayment,
                tableData: _tableData,
                jamiLizingSummasi: _totalLeaseAmount,
                jamiTolov: _totalPayment,
              ),
            ),
          );
        }
      });
    }
  }

  List<List<dynamic>> _calculateTableData(
      double remainingSum, int duration, double margin) {
    List<List<dynamic>> tableData = [];
    double monthlyPayment = _pmt(margin / 12, duration, remainingSum);

    for (int i = 0; i < duration; i++) {
      double ustama = remainingSum * margin / 12;
      double asosiyTani = monthlyPayment - ustama;
      tableData.add([i + 1, remainingSum, ustama, asosiyTani, monthlyPayment]);
      remainingSum -= asosiyTani;
    }
    return tableData;
  }

  double _pmt(double rate, int nper, double pv) {
    if (rate == 0) return -pv / nper;
    return pv * rate / (1 - math.pow(1 + rate, -nper));
  }

  Widget _buildSectionHeader(String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Text(
        title,
        style: TextStyle(
            fontFamily: 'Poppins', fontSize: 16, fontWeight: FontWeight.bold),
      ),
    );
  }

  Widget _buildCard(List<Widget> children) {
    return Card(
      elevation: 2.0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: children,
        ),
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    String? suffix,
    bool isCurrency = false,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: TextStyle(fontFamily: 'Poppins', fontSize: 16)),
          SizedBox(height: 8),
          TextFormField(
            controller: controller,
            keyboardType: TextInputType.number,
            decoration: InputDecoration(
              filled: true,
              fillColor: Colors.green[100],
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
              ),
              suffixText: suffix,
            ),
            inputFormatters:
                isCurrency ? [ThousandsSeparatorInputFormatter()] : [],
            validator: (value) {
              if (value == null || value.isEmpty) {
                return 'Iltimos, qiymatni kiriting';
              }
              try {
                double.parse(value.replaceAll(',', ''));
              } catch (e) {
                return 'To\'g\'ri raqamni kiriting';
              }
              return null;
            },
          ),
        ],
      ),
    );
  }

  Widget _buildDropdown({
    required TextEditingController controller,
    required String label,
    required List<String> items,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: TextStyle(fontFamily: 'Poppins', fontSize: 16)),
          SizedBox(height: 8),
          DropdownButtonFormField<String>(
            value:
                items.contains(controller.text) ? controller.text : items.first,
            onChanged: (value) {
              setState(() {
                controller.text = value!;
              });
            },
            items: items.map((String value) {
              return DropdownMenuItem<String>(
                value: value,
                child: Text(value, style: TextStyle(fontSize: 16)),
              );
            }).toList(),
            decoration: InputDecoration(
              filled: true,
              fillColor: Colors.green[100],
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
              ),
            ),
            validator: (value) {
              if (value == null || value.isEmpty) {
                return 'Iltimos, qiymatni tanlang';
              }
              return null;
            },
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title:
            Text('Lizing Kalkulyator', style: TextStyle(fontFamily: 'Poppins')),
        backgroundColor: Colors.green,
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildSectionHeader('Avtomashina narxi'),
              _buildTextField(
                  controller: _priceController,
                  label: 'Narx',
                  isCurrency: true),
              SizedBox(height: 20),
              _buildSectionHeader('Lizing sozlamalari'),
              Row(
                children: [
                  Expanded(
                    child: ListTile(
                      title: Text('Lizing',
                          style: TextStyle(fontFamily: 'Poppins')),
                      leading: Radio<String>(
                        value: 'Lizing',
                        groupValue: _selectedOption,
                        activeColor: Colors.green,
                        onChanged: (value) {
                          setState(() {
                            _selectedOption = value!;
                          });
                        },
                      ),
                    ),
                  ),
                  Expanded(
                    child: ListTile(
                      title: Text('Moliyaviy Ijara',
                          style: TextStyle(fontFamily: 'Poppins')),
                      leading: Radio<String>(
                        value: 'Moliyaviy Ijara',
                        groupValue: _selectedOption,
                        activeColor: Colors.green,
                        onChanged: (value) {
                          setState(() {
                            _selectedOption = value!;
                          });
                        },
                      ),
                    ),
                  ),
                ],
              ),
              _buildCard([
                _buildDropdown(
                    controller: _marginController,
                    label: 'Marja',
                    items: List.generate(
                        15,
                        (index) =>
                            (28 + index * 0.5).toStringAsFixed(1) + '%')),
                _buildDropdown(
                    controller: _insuranceController,
                    label: 'Sug\'urta',
                    items: List.generate(
                        11, (index) => (index * 0.1).toStringAsFixed(1) + '%')),
                _buildTextField(
                    controller: _gaiController, label: 'GAI', suffix: ' uzs'),
                _buildTextField(
                    controller: _gpsController, label: 'GPS', suffix: ' uzs'),
                _buildDropdown(
                    controller: _commissionController,
                    label: 'Komissiya xizmat haqi',
                    items: List.generate(15,
                        (index) => (3 + index * 0.5).toStringAsFixed(1) + '%')),
                _buildTextField(
                    controller: _initialPaymentController,
                    label: 'Boshlang\'ich to\'lov (%)',
                    suffix: '%',
                    isCurrency: false),
              ]),
              SizedBox(height: 20),
              _buildSectionHeader('Lizing Muddat'),
              Stack(
                children: [
                  Slider(
                    value: double.parse(_durationController.text),
                    min: 12,
                    max: 60,
                    divisions: 59,
                    activeColor: Colors.green,
                    label: _durationController.text,
                    onChanged: (value) {
                      setState(() {
                        _durationController.text = value.toStringAsFixed(0);
                      });
                    },
                  ),
                  Positioned(
                    left: 20,
                    top: 0,
                    child: Text(
                      '${_durationController.text} oy',
                      style: TextStyle(color: Colors.grey, fontSize: 16),
                    ),
                  ),
                ],
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: _calculate,
                child:
                    Text('Hisoblash', style: TextStyle(fontFamily: 'Poppins')),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green,
                  padding: EdgeInsets.symmetric(vertical: 16),
                  minimumSize: Size(double.infinity, 50),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class ThousandsSeparatorInputFormatter extends TextInputFormatter {
  final NumberFormat numberFormat = NumberFormat.decimalPattern('en');

  @override
  TextEditingValue formatEditUpdate(
      TextEditingValue oldValue, TextEditingValue newValue) {
    if (newValue.selection.baseOffset == 0) {
      return newValue;
    }

    double value = double.parse(newValue.text.replaceAll(',', ''));
    final newText = numberFormat.format(value);

    return newValue.copyWith(
      text: newText,
      selection: TextSelection.collapsed(offset: newText.length),
    );
  }
}
