import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:hamkoroffline/Login/employee_dashboard_page.dart';
import 'package:hamkoroffline/Login/login_screen.dart';
import 'package:hamkoroffline/Login/super_admin.dart';
import 'package:hamkoroffline/cars/item.dart';
import 'package:hamkoroffline/cars/item_detail_page.dart';
import 'package:hamkoroffline/dashbord_page.dart';
import 'package:hamkoroffline/models/leasing_calculator.dart';
import 'package:hamkoroffline/models/leasing_services_page.dart';
import 'package:hamkoroffline/models/meyory_hujjat.dart';
import 'package:hamkoroffline/models/nav_bar.dart';
import 'package:intl/intl.dart';
import 'package:hamkoroffline/pages/home_page.dart'; // Ensure you import the required pages

class AllProductsPage extends StatefulWidget {
  final String categoryTitle;

  const AllProductsPage({Key? key, required this.categoryTitle}) : super(key: key);

  @override
  _AllProductsPageState createState() => _AllProductsPageState();
}

class _AllProductsPageState extends State<AllProductsPage> {
  final DatabaseReference _itemsRef = FirebaseDatabase.instance.ref().child('items');
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>(); // Define a GlobalKey for the Scaffold

  List<Item> items = [];
  List<Item> filteredItems = [];
  String searchQuery = '';
  String selectedBrand = '';
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    fetchItems();
  }

  void fetchItems() {
    _itemsRef.onValue.listen((event) {
      if (event.snapshot.exists) {
        final Map<String, dynamic>? data = Map<String, dynamic>.from(event.snapshot.value as Map? ?? {});
        final List<Item> loadedItems = [];
        data?.forEach((key, value) {
          if (value != null) {
            try {
              final item = Item.fromMap(Map<String, dynamic>.from(value), key);
              loadedItems.add(item);
            } catch (e) {
              print("Error parsing item: $e");
            }
          }
        });
        setState(() {
          items = loadedItems;
          filteredItems = items;
          isLoading = false;
        });
      } else {
        setState(() {
          items = [];
          filteredItems = [];
          isLoading = false;
        });
      }
    }).onError((error) {
      setState(() {
        isLoading = false;
      });
    });
  }

  void updateSearchQuery(String newQuery) {
    setState(() {
      searchQuery = newQuery;
      filteredItems = items.where((item) {
        final itemNameLower = item.name.toLowerCase();
        final searchLower = searchQuery.toLowerCase();
        return itemNameLower.contains(searchLower);
      }).toList();
    });
  }

  void filterByBrand(String brand) {
    setState(() {
      selectedBrand = brand;
      filteredItems = items.where((item) {
        return item.name.toLowerCase().contains(brand.toLowerCase());
      }).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey, // Assign the GlobalKey to the Scaffold
      appBar: CustomNavBar(
        onDrawerIconPressed: () {
          _scaffoldKey.currentState?.openDrawer(); // Open the drawer using the GlobalKey
        },
      ),
      drawer: _buildDrawer(context), // Use the _buildDrawer method for the drawer content
      body: isLoading
          ? Center(child: CircularProgressIndicator())
          : Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: TextField(
              decoration: InputDecoration(
                hintText: 'Qidirish...',
                prefixIcon: Icon(Icons.search, color: Colors.green),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(30.0),
                  borderSide: BorderSide.none,
                ),
                filled: true,
                fillColor: Colors.green.shade50,
              ),
              onChanged: updateSearchQuery,
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8.0),
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  _buildBrandIcon('Mercedes-Benz', 'assets/icons/merc.png'),
                  _buildBrandIcon('Chevrolet', 'assets/icons/chevrolet.png'),
                  _buildBrandIcon('Zeekr', 'assets/icons/zeekr.png'),
                  _buildBrandIcon('Chery', 'assets/icons/chery.png'),
                  _buildBrandIcon('CHANGAN', 'assets/icons/changan.png'),
                  _buildBrandIcon('AVATR', 'assets/icons/avatr.png'),
                  _buildBrandIcon('BYD', 'assets/icons/BYD.png'),
                  _buildBrandIcon('BAIC', 'assets/icons/baic.png'),
                  _buildBrandIcon('Haval', 'assets/icons/haval.png'),
                  _buildBrandIcon('Jac', 'assets/icons/jac.png'),
                  _buildBrandIcon('Leap Motor', 'assets/icons/leap_motor.png'),
                  _buildBrandIcon('Caterpillar', 'assets/icons/caterpillar.png'),
                  _buildBrandIcon('Bomag', 'assets/icons/bomag.png'),
                  _buildBrandIcon('Komatsu', 'assets/icons/komatsu.png'),
                  _buildBrandIcon('SDLG', 'assets/icons/sdlg.png'),
                  _buildBrandIcon('JCB', 'assets/icons/jcb.png'),
                  _buildBrandIcon('LiuGong', 'assets/icons/liugong.png'),
                  _buildBrandIcon('John Deere', 'assets/icons/john_deere.png'),
                  _buildBrandIcon('Case IH', 'assets/icons/case_ih.png'),
                  _buildBrandIcon('New Holland', 'assets/icons/new_holland.png'),
                  _buildBrandIcon('CNC', 'assets/icons/cnc.png'),
                ],
              ),
            ),
          ),
          Expanded(
            child: GridView.builder(
              padding: const EdgeInsets.all(12.0),
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: MediaQuery.of(context).size.width > 1200
                    ? 4
                    : MediaQuery.of(context).size.width > 900
                    ? 3
                    : 2,
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
                childAspectRatio: MediaQuery.of(context).size.width > 900
                    ? 0.75
                    : 0.8,
              ),
              itemCount: filteredItems.length,
              itemBuilder: (context, index) {
                final item = filteredItems[index];
                return _buildItemCard(context, item);
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBrandIcon(String brand, String iconPath) {
    return GestureDetector(
      onTap: () => filterByBrand(brand),
      child: AnimatedContainer(
        duration: Duration(milliseconds: 300),
        margin: const EdgeInsets.symmetric(horizontal: 6.0),
        width: 60,
        height: 60,
        decoration: BoxDecoration(
          color: selectedBrand == brand ? Colors.green.shade50 : Colors.white,
          borderRadius: BorderRadius.circular(10.0),
          boxShadow: [
            BoxShadow(
              color: Colors.black12,
              offset: Offset(0, 3),
              blurRadius: 6,
            ),
          ],
          border: Border.all(
            color: selectedBrand == brand ? Colors.green : Colors.grey.shade300,
            width: 2,
          ),
        ),
        child: Image.asset(iconPath, fit: BoxFit.contain),
      ),
    );
  }

  Widget _buildItemCard(BuildContext context, Item item) {
    final NumberFormat currencyFormat = NumberFormat.currency(
      locale: 'uz_UZ',
      symbol: item.currency,
      decimalDigits: 0,
    );

    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => ItemDetailPage(item: item)),
        );
      },
      child: Card(
        elevation: 10,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: ClipRRect(
                borderRadius: BorderRadius.vertical(top: Radius.circular(15)),
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [Colors.green.shade100, Colors.green.shade400],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                  ),
                  child: Image.network(
                    item.imagePaths.isNotEmpty ? item.imagePaths.first : '',
                    fit: BoxFit.cover,
                    width: double.infinity,
                    height: 200,
                    errorBuilder: (context, error, stackTrace) {
                      return Center(
                        child: Icon(
                          Icons.broken_image,
                          color: Colors.grey,
                          size: 50,
                        ),
                      );
                    },
                    loadingBuilder: (context, child, loadingProgress) {
                      if (loadingProgress == null) {
                        return child;
                      }
                      return Center(
                        child: CircularProgressIndicator(),
                      );
                    },
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(10.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    item.name,
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.green.shade800,
                    ),
                  ),
                  SizedBox(height: 4),
                  Text(
                    'Narxi: ${currencyFormat.format(item.price)}',
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                      color: Colors.redAccent,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDrawer(BuildContext context) {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: <Widget>[
          DrawerHeader(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Color(0xFF1B5E20), Color(0xFF4CAF50)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
            child: Text(
              'Hamkor Lizing',
              style: TextStyle(
                color: Colors.white,
                fontSize: 24,
                fontWeight: FontWeight.bold,
                shadows: [
                  Shadow(
                    blurRadius: 10.0,
                    color: Colors.black45,
                    offset: Offset(2.0, 2.0),
                  ),
                ],
              ),
            ),
          ),
          _buildNavButton(
            context,
            title: 'Bosh sahifa',
            destination: HomePage(),
            icon: Icons.home,
          ),
          _buildNavButton(
            context,
            title: 'Barcha Mahsulotlar',
            destination: AllProductsPage(categoryTitle: 'Barcha Mahsulotlar'),
            icon: Icons.directions_car,
          ),
          _buildNavButton(
            context,
            title: 'Xizmatlar',
            destination: LeasingServicesPage(),
            icon: Icons.business_center,
          ),
          _buildNavButton(
            context,
            title: 'Lizing Kalkulyator',
            destination: LeasingOptionsPage(),
            icon: Icons.calculate,
          ),
          _buildNavButton(
            context,
            title: 'Me\'yoriy Hujjatlar',
            destination: MeyoriyHujjatlarPage(),
            icon: Icons.file_copy,
          ),
          if (FirebaseAuth.instance.currentUser != null)
            FutureBuilder<Widget>(
              future: _determineDestination(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: CircularProgressIndicator(),
                  );
                } else if (snapshot.hasError) {
                  return Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text('Error: ${snapshot.error}'),
                  );
                } else if (snapshot.hasData) {
                  return _buildNavButton(
                    context,
                    title: 'Shaxsiy Hisobim',
                    destination: snapshot.data!,
                    icon: Icons.account_circle,
                  );
                } else {
                  return Container();
                }
              },
            ),
          if (FirebaseAuth.instance.currentUser == null)
            _buildNavButton(
              context,
              title: 'Kirish',
              destination: LoginScreen(),
              icon: Icons.login,
            ),
        ],
      ),
    );
  }

  Widget _buildNavButton(BuildContext context, {required String title, required Widget destination, required IconData icon}) {
    return ListTile(
      leading: Icon(icon, color: Colors.green),
      title: Text(
        title,
        style: TextStyle(
          color: Colors.green.shade800,
          fontWeight: FontWeight.bold,
        ),
      ),
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => destination),
        );
      },
    );
  }

  Future<Widget> _determineDestination() async {
    User? currentUser = FirebaseAuth.instance.currentUser;

    if (currentUser == null) {
      return LoginScreen();
    }

    String email = currentUser.email?.toLowerCase() ?? '';
    final roleRef = FirebaseDatabase.instance
        .ref()
        .child('profiles/${currentUser.uid}/role');

    final DatabaseEvent event = await roleRef.once();
    final String role = event.snapshot.value as String? ?? '';

    if (role == 'SuperAdmin' || email == 'buxorovbahodir11@gmail.com') {
      return SuperAdminProfilePage();
    } else if (role == 'Bosh Direktor') {
      return AdminDashboardPage();
    } else {
      return EmployeeDashboardPage(user: currentUser);
    }
  }
}
