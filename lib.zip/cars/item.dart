class Item {
  final String id;
  final String name;
  final String description;
  final List<String> imagePaths;
  final String fuelType;
  final String year;
  final String enginePower;
  final String type;
  final double price;
  final String currency; // Currency field

  Item({
    required this.id,
    required this.name,
    required this.description,
    required this.imagePaths,
    required this.fuelType,
    required this.year,
    required this.enginePower,
    required this.type,
    required this.price,
    required this.currency, // Initialize currency
  });

  factory Item.fromMap(Map<String, dynamic> map, String id) {
    return Item(
      id: id,
      name: map['name'] ?? '',
      description: map['description'] ?? '',
      imagePaths: List<String>.from(map['imagePaths'] ?? []),
      fuelType: map['fuelType'] ?? '',
      year: map['year'] ?? '',
      enginePower: map['enginePower'] ?? '',
      type: map['type'] ?? '',
      price: map['price']?.toDouble() ?? 0.0,
      currency: map['currency'] ?? 'UZS', // Assign currency
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'description': description,
      'imagePaths': imagePaths,
      'fuelType': fuelType,
      'year': year,
      'enginePower': enginePower,
      'type': type,
      'price': price,
      'currency': currency, // Map currency
    };
  }
}
