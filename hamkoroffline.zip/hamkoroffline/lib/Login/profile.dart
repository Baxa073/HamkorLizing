import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';

class ProfilePage extends StatefulWidget {
  @override
  _ProfilePageState createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  late DatabaseReference dbRef;
  User? currentUser;
  Map<String, dynamic> userData = {};

  @override
  void initState() {
    super.initState();
    currentUser = FirebaseAuth.instance.currentUser;

    if (currentUser == null) {
      // Agar foydalanuvchi tizimga kirmagan bo'lsa, uni LoginPage sahifasiga yo'naltiramiz
      WidgetsBinding.instance.addPostFrameCallback((_) {
        Navigator.pushReplacementNamed(context, '/login');
      });
    } else {
      dbRef = FirebaseDatabase.instance
          .ref()
          .child('profiles')
          .child(currentUser!.uid);
      fetchUserData();
    }
  }

  void fetchUserData() async {
    DataSnapshot snapshot = await dbRef.get();
    if (snapshot.exists) {
      setState(() {
        userData = Map<String, dynamic>.from(snapshot.value as Map);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (currentUser == null) {
      // Agar foydalanuvchi tizimga kirmagan bo'lsa, hech narsa ko'rsatilmaydi,
      // Foydalanuvchi LoginPage ga yo'naltiriladi
      return Container();
    }

    String role = userData['role'] ?? 'Default';
    String profileImage = (role == 'Hodim' || role == 'Boshliq')
        ? 'assets/images/hodim.jpg'
        : 'assets/images/deafult.jpg';

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.green, // Yashil rang
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        title: Text('Profile Settings'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text(
              'Your Profile Information',
              style: TextStyle(fontSize: 16, color: Colors.grey),
            ),
            SizedBox(height: 20),
            Stack(
              children: [
                CircleAvatar(
                  radius: 50,
                  backgroundImage: AssetImage(profileImage),
                ),
                Positioned(
                  bottom: 0,
                  right: 0,
                  child: CircleAvatar(
                    backgroundColor: Colors.green, // Yashil rang
                    radius: 15,
                    child: Icon(Icons.edit, color: Colors.white, size: 18),
                  ),
                ),
              ],
            ),
            SizedBox(height: 20),
            Text(
              '${userData['firstname'] ?? ''} ${userData['lastname'] ?? ''}',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 5),
            Text(
              userData['email'] ?? '',
              style: TextStyle(fontSize: 16, color: Colors.grey),
            ),
            SizedBox(height: 20),
            buildInfoSection(),
          ],
        ),
      ),
    );
  }

  Widget buildInfoSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Personal Information',
          style: TextStyle(
              fontSize: 16, fontWeight: FontWeight.bold, color: Colors.green),
        ),
        SizedBox(height: 10),
        buildInfoTile('Account Number', userData['account_number'] ?? ''),
        buildInfoTile('Username',
            '${userData['firstname'] ?? ''} ${userData['lastname'] ?? ''}'),
        buildInfoTile('Email', userData['email'] ?? ''),
        buildInfoTile('Mobile Phone', userData['phone'] ?? ''),
        buildInfoTile('Address', userData['address'] ?? ''),
        buildInfoTile('Role', userData['role'] ?? ''),
        SizedBox(height: 20),
        Text(
          'Security',
          style: TextStyle(
              fontSize: 16, fontWeight: FontWeight.bold, color: Colors.green),
        ),
        SizedBox(height: 10),
        buildSecurityTile('Change Pin'),
        buildSecurityTile('Change Password'),
        buildSwitchTile('Finger Print', true),
        SizedBox(height: 20),
        Text(
          'Other',
          style: TextStyle(
              fontSize: 16, fontWeight: FontWeight.bold, color: Colors.green),
        ),
      ],
    );
  }

  Widget buildInfoTile(String title, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Container(
        padding: EdgeInsets.all(16.0),
        decoration: BoxDecoration(
          color: Colors.grey[200],
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(title,
                style: TextStyle(fontSize: 16, color: Colors.grey[700])),
            Text(value, style: TextStyle(fontSize: 16, color: Colors.black)),
          ],
        ),
      ),
    );
  }

  Widget buildSecurityTile(String title) {
    return ListTile(
      title: Text(title),
      trailing: Icon(Icons.arrow_forward_ios, color: Colors.grey),
      onTap: () {
        // Security related functionality
      },
    );
  }

  Widget buildSwitchTile(String title, bool value) {
    return ListTile(
      title: Text(title),
      trailing: Switch(
        value: value,
        onChanged: (newValue) {
          setState(() {
            // Toggle the switch
          });
        },
        activeColor: Colors.green,
      ),
    );
  }
}
