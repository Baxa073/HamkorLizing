import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:awesome_snackbar_content/awesome_snackbar_content.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hamkoroffline/dashbord_page.dart';
import 'package:hamkoroffline/pages/add_item_page.dart';

class SuperAdminProfilePage extends StatefulWidget {
  @override
  _SuperAdminProfilePageState createState() => _SuperAdminProfilePageState();
}

class _SuperAdminProfilePageState extends State<SuperAdminProfilePage> {
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController nameController = TextEditingController();
  final TextEditingController phoneController = TextEditingController();
  final TextEditingController newEmailController = TextEditingController();
  final TextEditingController newPasswordController = TextEditingController();
  final TextEditingController searchController = TextEditingController();

  final FirebaseAuth _auth = FirebaseAuth.instance;
  final DatabaseReference _database =
      FirebaseDatabase.instance.ref().child('profiles');

  List<Map<dynamic, dynamic>> employees = [];
  List<Map<dynamic, dynamic>> filteredEmployees = [];
  String selectedRole = 'Hodim'; // Default role
  String selectedRegion = 'Андижанская'; // Default region

  final List<String> regions = [
    'Андижанская',
    'Ташкентская',
    'Бухарская',
    'Ферганская',
    'Джизакская',
    'Навоийская',
    'Кашкадарьинская',
    'Самаркандская',
    'Сурхандарьинская',
    'Хорезмская',
    'Республика Каракалпакистан',
    'г. Ташкент'
  ];

  @override
  void initState() {
    super.initState();
    checkSuperAdmin();
    fetchEmployees();
  }

  void checkSuperAdmin() async {
    User? user = _auth.currentUser;
    if (user?.email != 'buxorovbahodir11@gmail.com') {
      Navigator.of(context).pushReplacement(MaterialPageRoute(
        builder: (context) => NotAuthorizedPage(),
      ));
    }
  }

  void fetchEmployees() async {
    _database.once().then((DatabaseEvent event) {
      final data = event.snapshot.value;
      if (data != null) {
        List<Map<dynamic, dynamic>> tempList = [];
        if (data is Map) {
          (data as Map<dynamic, dynamic>).forEach((key, value) {
            if (value != null) {
              Map<dynamic, dynamic> employee = value as Map<dynamic, dynamic>;
              employee['uid'] = key;
              tempList.add(employee);
            }
          });
        }
        setState(() {
          employees = tempList;
          filteredEmployees = employees;
        });
      }
    });
  }

  void _logout() async {
    await _auth.signOut();
    Navigator.pushReplacementNamed(context, '/login');
  }

  void _searchEmployee(String query) {
    final suggestions = employees.where((employee) {
      final employeeName = employee['name']?.toString().toLowerCase() ?? '';
      final employeeEmail = employee['email']?.toString().toLowerCase() ?? '';
      final input = query.toLowerCase();
      return employeeName.contains(input) || employeeEmail.contains(input);
    }).toList();
    setState(() {
      filteredEmployees = suggestions;
    });
  }

  void _deleteEmployee(String uid) async {
    try {
      await _database.child(uid).remove();
      fetchEmployees();
      _showSnackBar('Muvaffaqiyat', 'Hodim muvaffaqiyatli o\'chirildi',
          ContentType.success);
    } catch (e) {
      _showSnackBar(
          'Xatolik', 'Xatolik yuz berdi: ${e.toString()}', ContentType.failure);
    }
  }

  void _editEmployee(
      String uid, String newName, String newPhone, String newRegion) async {
    try {
      await _database.child(uid).update({
        'name': newName,
        'phone': newPhone,
        'region': newRegion,
      });
      fetchEmployees();
      _showSnackBar('Muvaffaqiyat', 'Hodim ma\'lumotlari yangilandi',
          ContentType.success);
    } catch (e) {
      _showSnackBar(
          'Xatolik', 'Xatolik yuz berdi: ${e.toString()}', ContentType.failure);
    }
  }

  void _addNewEmployee() async {
    if (_validateFields()) {
      try {
        UserCredential userCredential =
            await _auth.createUserWithEmailAndPassword(
          email: newEmailController.text,
          password: newPasswordController.text,
        );

        User? user = userCredential.user;
        if (user != null) {
          await _database.child(user.uid).set({
            'name': nameController.text,
            'phone': phoneController.text,
            'region': selectedRegion,
            'email': newEmailController.text,
            'role': selectedRole,
            'imageUrl': '',
          });

          _clearFields();
          _showSnackBar('Muvaffaqiyat', 'Hodim muvaffaqiyatli qo\'shildi',
              ContentType.success);
          fetchEmployees();
        }
      } catch (e) {
        _showSnackBar('Xatolik', 'Xatolik yuz berdi: ${e.toString()}',
            ContentType.failure);
      }
    }
  }

  bool _validateFields() {
    if (newEmailController.text.isEmpty ||
        newPasswordController.text.isEmpty ||
        nameController.text.isEmpty ||
        phoneController.text.isEmpty ||
        selectedRegion.isEmpty ||
        selectedRole.isEmpty) {
      _showSnackBar('Xatolik', 'Iltimos, barcha maydonlarni to\'ldiring',
          ContentType.failure);
      return false;
    }
    return true;
  }

  void _clearFields() {
    newEmailController.clear();
    newPasswordController.clear();
    nameController.clear();
    phoneController.clear();
    setState(() {
      selectedRole = 'Hodim';
      selectedRegion = 'Андижанская';
    });
  }

  void _showSnackBar(String title, String message, ContentType contentType) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        behavior: SnackBarBehavior.floating,
        content: AwesomeSnackbarContent(
          title: title,
          message: message,
          contentType: contentType,
        ),
      ),
    );
  }

  void _updateEmployeeProfile() async {
    try {
      String email = emailController.text;
      String newPassword = passwordController.text;

      User? user = (await _auth.fetchSignInMethodsForEmail(email)).isNotEmpty
          ? (await _auth.signInWithEmailAndPassword(
                  email: email, password: newPassword))
              .user
          : null;

      if (user != null) {
        await user.updatePassword(newPassword);
        _showSnackBar('Muvaffaqiyat', 'Hodim profili muvaffaqiyatli yangilandi',
            ContentType.success);
      } else {
        _showSnackBar('Xatolik', 'Hodim topilmadi', ContentType.failure);
      }
    } catch (e) {
      _showSnackBar(
          'Xatolik', 'Xatolik yuz berdi: ${e.toString()}', ContentType.failure);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Super Admin Profili',
            style: GoogleFonts.poppins(fontWeight: FontWeight.bold)),
        backgroundColor: Colors.green,
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pushReplacementNamed(context, '/home');
          },
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.logout),
            onPressed: _logout,
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            Text('Hodim Profilini Yangilash',
                style: GoogleFonts.poppins(
                    fontSize: 20, fontWeight: FontWeight.bold)),
            buildTextField(emailController, 'Hodim Emaili'),
            buildTextField(passwordController, 'Yangi Parol'),
            ElevatedButton(
              onPressed: _updateEmployeeProfile,
              style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
              child: Text('Profilni Yangilash', style: GoogleFonts.poppins()),
            ),
            SizedBox(height: 20),
            Text('Yangi Hodim Qo\'shish',
                style: GoogleFonts.poppins(
                    fontSize: 20, fontWeight: FontWeight.bold)),
            buildTextField(newEmailController, 'Email'),
            buildTextField(newPasswordController, 'Parol'),
            buildTextField(nameController, 'Ism'),
            buildTextField(phoneController, 'Telefon'),
            buildRegionDropdown(),
            buildRoleDropdown(),
            ElevatedButton(
              onPressed: _addNewEmployee,
              style: ElevatedButton.styleFrom(backgroundColor: Colors.blue),
              child: Text('Hodim Qo\'shish', style: GoogleFonts.poppins()),
            ),

            SizedBox(height: 20),
            Text('Hodimlarni qidirish',
                style: GoogleFonts.poppins(
                    fontSize: 20, fontWeight: FontWeight.bold)),
            buildTextField(searchController, 'Qidirish'),
            ElevatedButton(
              onPressed: () => _searchEmployee(searchController.text),
              style: ElevatedButton.styleFrom(backgroundColor: Colors.orange),
              child: Text('Qidirish', style: GoogleFonts.poppins()),
            ),
            SizedBox(height: 20),
            Text('Hodimlar Ro\'yxati',
                style: GoogleFonts.poppins(
                    fontSize: 20, fontWeight: FontWeight.bold)),
            buildEmployeeTable(),

            // Admin Dashboard sahifasiga o'tish tugmasi
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => AdminDashboardPage()),
                );
              },
              child: Text('Admin Dashboardga o\'tish'),
              style: ElevatedButton.styleFrom(
                foregroundColor: Colors.white, backgroundColor: Colors.green,
              ),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => AddItemPage()),
                );
              },
              child: Text('Texnika qo\'shish'),
              style: ElevatedButton.styleFrom(
                foregroundColor: Colors.white, backgroundColor: Colors.green,
              ),
            ),
          ],
        ),
      ),

    );
  }

  Widget buildTextField(TextEditingController controller, String label) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: TextField(
        controller: controller,
        decoration: InputDecoration(
          labelText: label,
          labelStyle: TextStyle(color: Colors.green),
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(color: Colors.green),
            borderRadius: BorderRadius.circular(10),
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: BorderSide(color: Colors.green),
            borderRadius: BorderRadius.circular(10),
          ),
        ),
      ),
    );
  }

  Widget buildRoleDropdown() {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: DropdownButtonFormField<String>(
        decoration: InputDecoration(
          labelText: 'Hodim Roli',
          labelStyle: TextStyle(color: Colors.green),
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(color: Colors.green),
            borderRadius: BorderRadius.circular(10),
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: BorderSide(color: Colors.green),
            borderRadius: BorderRadius.circular(10),
          ),
        ),
        value: selectedRole,
        items: ['Super Admin', 'Bosh Direktor', 'Hodim']
            .map((role) => DropdownMenuItem<String>(
                  value: role,
                  child: Text(role),
                ))
            .toList(),
        onChanged: (newValue) {
          setState(() {
            selectedRole = newValue!;
          });
        },
      ),
    );
  }

  Widget buildRegionDropdown() {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: DropdownButtonFormField<String>(
        decoration: InputDecoration(
          labelText: 'Viloyat',
          labelStyle: TextStyle(color: Colors.green),
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(color: Colors.green),
            borderRadius: BorderRadius.circular(10),
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: BorderSide(color: Colors.green),
            borderRadius: BorderRadius.circular(10),
          ),
        ),
        value: selectedRegion,
        items: regions
            .map((region) => DropdownMenuItem<String>(
                  value: region,
                  child: Text(region),
                ))
            .toList(),
        onChanged: (newValue) {
          setState(() {
            selectedRegion = newValue!;
          });
        },
      ),
    );
  }

  Widget buildEmployeeTable() {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: DataTable(
        columns: [
          DataColumn(label: Icon(Icons.person)),
          DataColumn(label: Text('Ism')),
          DataColumn(label: Text('Email')),
          DataColumn(label: Text('Role')),
          DataColumn(label: Text('Viloyat')),
          DataColumn(label: Text('Action')),
        ],
        rows: filteredEmployees.map((employee) {
          return DataRow(cells: [
            DataCell(Icon(Icons.person)),
            DataCell(Text(employee['name'] ?? '')),
            DataCell(Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(employee['email'] ?? ''),
                Text(employee['phone'] ?? ''),
              ],
            )),
            DataCell(Text(employee['role'] ?? '')),
            DataCell(Text(employee['region'] ?? '')),
            DataCell(Row(
              children: [
                IconButton(
                  icon: Icon(Icons.edit),
                  onPressed: () {
                    nameController.text = employee['name'] ?? '';
                    phoneController.text = employee['phone'] ?? '';
                    selectedRegion = employee['region'] ?? '';
                    showDialog(
                      context: context,
                      builder: (context) {
                        return AlertDialog(
                          title: Text('Hodim ma\'lumotlarini tahrirlash'),
                          content: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              buildTextField(nameController, 'Ism'),
                              buildTextField(phoneController, 'Telefon'),
                              buildRegionDropdown(),
                            ],
                          ),
                          actions: [
                            TextButton(
                              onPressed: () {
                                _editEmployee(
                                    employee['uid'],
                                    nameController.text,
                                    phoneController.text,
                                    selectedRegion);
                                Navigator.of(context).pop();
                              },
                              child: Text('Saqlash'),
                            ),
                            TextButton(
                              onPressed: () {
                                Navigator.of(context).pop();
                              },
                              child: Text('Bekor qilish'),
                            ),
                          ],
                        );
                      },
                    );
                  },
                ),

                IconButton(
                  icon: Icon(Icons.delete),
                  onPressed: () {
                    _deleteEmployee(employee['uid']);
                  },
                ),
              ],
            )),
          ]);
        }).toList(),
      ),
    );
  }
}

class NotAuthorizedPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Kirish Rad Etildi',
            style: GoogleFonts.poppins(fontWeight: FontWeight.bold)),
        backgroundColor: Colors.red,
      ),
      body: Center(
        child: Text(
          'Sizda bu sahifaga kirish huquqi yo\'q.',
          style: GoogleFonts.poppins(fontSize: 18),
        ),
      ),
    );
  }
}
