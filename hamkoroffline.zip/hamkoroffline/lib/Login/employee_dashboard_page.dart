import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:intl/intl.dart';
import 'package:getwidget/getwidget.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:syncfusion_flutter_xlsio/xlsio.dart' hide Column, Row;
import 'dart:html' as html;

class EmployeeDashboardPage extends StatefulWidget {
  final User user;
  EmployeeDashboardPage({required this.user});

  @override
  _EmployeeDashboardPageState createState() => _EmployeeDashboardPageState();
}

class _EmployeeDashboardPageState extends State<EmployeeDashboardPage> {
  final DatabaseReference databaseReference = FirebaseDatabase.instance.ref();
  List<Map<dynamic, dynamic>> leasingDataList = [];
  List<Map<dynamic, dynamic>> filteredList = [];
  bool isLoading = true;
  bool hasError = false;
  int totalProjects = 0;
  int totalDebtors = 0;
  String selectedRegion = 'Барча';
  bool showAllProjects = true;
  String userName = '';

  final RefreshController _refreshController =
  RefreshController(initialRefresh: false);

  @override
  void initState() {
    super.initState();
    fetchUserName();
  }

  void fetchUserName() {
    databaseReference
        .child("profiles")
        .child(widget.user.uid)
        .once()
        .then((DatabaseEvent event) {
      final data = event.snapshot.value;
      if (data != null && data is Map<dynamic, dynamic>) {
        setState(() {
          userName = data['name'] ?? '';
        });
        fetchData();
      } else {
        setState(() {
          isLoading = false;
          hasError = true;
        });
      }
    }).catchError((error) {
      setState(() {
        hasError = true;
        isLoading = false;
      });
      print('Error fetching user name: $error');
    });
  }

  bool _namesMatch(String nameFromDatabase, String nameFromUser) {
    String formattedNameFromDatabase = nameFromDatabase
        .replaceAll('‘', '\'')
        .replaceAll('O‘', 'O\'')
        .replaceAll('o‘', 'o\'');
    String formattedNameFromUser = nameFromUser
        .replaceAll('‘', '\'')
        .replaceAll('O‘', 'O\'')
        .replaceAll('o‘', 'o\'');
    return formattedNameFromDatabase == formattedNameFromUser;
  }

  void fetchData() {
    databaseReference.child("leasing").once().then((DatabaseEvent event) {
      final data = event.snapshot.value;
      if (data != null) {
        List<Map<dynamic, dynamic>> tempList = [];
        if (data is Map) {
          data.forEach((key, value) {
            if (value != null && value is Map<dynamic, dynamic>) {
              tempList.add(value);
            }
          });
        } else if (data is List) {
          for (var value in data) {
            if (value != null && value is Map<dynamic, dynamic>) {
              tempList.add(value);
            }
          }
        }

        setState(() {
          leasingDataList = tempList
              .where((item) =>
          item['Мутахассиси'] != null &&
              _namesMatch(
                  item['Мутахассиси'].toString().toUpperCase(), userName))
              .toList();
          filteredList = leasingDataList; // Initialize filteredList
          totalProjects = leasingDataList.length;
          totalDebtors = leasingDataList.where((project) {
            double jamiLizingTani = project['Жами лизинг таннархи'] is String
                ? double.tryParse(project['Жами лизинг таннархи']) ?? 0
                : project['Жами лизинг таннархи'] ?? 0;
            double penya = project['Пеня'] is String
                ? double.tryParse(project['Пеня']) ?? 0
                : project['Пеня'] ?? 0;
            double foizdan = project['Фоиздан'] is String
                ? double.tryParse(project['Фоиздан']) ?? 0
                : project['Фоиздан'] ?? 0;

            double jamiKarz = jamiLizingTani + penya + foizdan;
            return jamiKarz > 0;
          }).length;
          isLoading = false;
          hasError = false;
        });
      } else {
        setState(() {
          isLoading = false;
          hasError = true;
        });
      }
    }).catchError((error) {
      setState(() {
        hasError = true;
        isLoading = false;
      });
      print('Error fetching data: $error');
    });
  }

  void filterData() {
    setState(() {
      filteredList = leasingDataList.where((client) {
        bool matchesRegion = selectedRegion == 'Барча' ||
            client['Мижоз рўйхатдан ўтган худуд']?.toString() == selectedRegion;

        if (!matchesRegion) {
          return false;
        }

        if (showAllProjects) {
          return true;
        } else {
          double jamiLizingTani = client['Жами лизинг таннархи'] is String
              ? double.tryParse(client['Жами лизинг таннархи']) ?? 0
              : client['Жами лизинг таннархи'] ?? 0;
          double penya = client['Пеня'] is String
              ? double.tryParse(client['Пеня']) ?? 0
              : client['Пеня'] ?? 0;
          double foizdan = client['Фоиздан'] is String
              ? double.tryParse(client['Фоиздан']) ?? 0
              : client['Фоиздан'] ?? 0;

          double jamiKarz = jamiLizingTani + penya + foizdan;

          return jamiKarz > 0;
        }
      }).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Xodim Kabineti'),
        backgroundColor: Colors.green,
        actions: [
          IconButton(
            icon: Icon(Icons.save_alt),
            onPressed: generateExcel,
          ),
          IconButton(
            icon: Icon(Icons.logout),
            onPressed: () {
              FirebaseAuth.instance.signOut();
              Navigator.pushNamedAndRemoveUntil(
                context,
                '/home',
                    (Route<dynamic> route) => false,
              );
            },
          ),
        ],
      ),
      body: isLoading
          ? Center(
        child: SpinKitFadingCircle(
          color: Colors.green,
          size: 50.0,
        ),
      )
          : hasError
          ? Center(
        child: Text(
          'Ma\'lumotlarni yuklashda xatolik',
          style: TextStyle(color: Colors.red, fontSize: 18),
        ),
      )
          : SmartRefresher(
        controller: _refreshController,
        onRefresh: _refreshData,
        header: WaterDropHeader(
          waterDropColor: Colors.green,
        ),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              buildSummaryCards(),
              SizedBox(height: 20),
              buildFilters(),
              SizedBox(height: 20),
              buildCheckboxOptions(),
              SizedBox(height: 20),
              buildProjectSummary(),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _refreshData() async {
    setState(() {
      isLoading = true;
    });
    fetchData();
  }

  Widget buildSummaryCards() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            buildSummaryIconCard('Jami Loyihalar', totalProjects.toString(),
                Icons.assignment, Colors.blue),
            buildSummaryIconCard('Qarzdor Loyihalar', totalDebtors.toString(),
                Icons.error, Colors.red),
          ],
        ),
      ],
    );
  }

  Widget buildSummaryIconCard(String title, String value, IconData icon,
      Color iconColor) {
    return Column(
      children: [
        Icon(icon, color: iconColor, size: 40),
        SizedBox(height: 5),
        Text(
          title,
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
        Text(
          value,
          style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
        ),
      ],
    );
  }

  Widget buildFilters() {
    List<String> regions = [
      'Барча',
      'Андижанская',
      'Ташкентская',
      'Бухарская',
      'Ферганская',
      'Джизакская',
      'Навоийская',
      'Кашкадарьинская',
      'Самаркандская',
      'Сурхандарьинская',
      'Хорезмская',
      'Республика Каракалпакистан',
      'г. Ташкент'
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        DropdownButtonFormField<String>(
          decoration: InputDecoration(
            labelText: "Худудни танланг",
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
            ),
          ),
          value: selectedRegion,
          items: regions.map((String value) {
            return DropdownMenuItem<String>(
              value: value,
              child: Text(value),
            );
          }).toList(),
          onChanged: (newValue) {
            setState(() {
              selectedRegion = newValue!;
              filterData(); // Filter data when selection changes
            });
          },
        ),
      ],
    );
  }

  Widget buildCheckboxOptions() {
    return Row(
      children: [
        GFCheckbox(
          size: GFSize.SMALL,
          activeBgColor: GFColors.SUCCESS,
          onChanged: (value) {
            setState(() {
              showAllProjects = value;
              filterData(); // Filter data when checkbox changes
            });
          },
          value: showAllProjects,
        ),
        SizedBox(width: 10),
        Text("Hammasi"),
        SizedBox(width: 20),
        GFCheckbox(
          size: GFSize.SMALL,
          activeBgColor: GFColors.DANGER,
          onChanged: (value) {
            setState(() {
              showAllProjects = !value;
              filterData(); // Filter data when checkbox changes
            });
          },
          value: !showAllProjects,
        ),
        SizedBox(width: 10),
        Text("Muddati O'tgan"),
      ],
    );
  }

  Widget buildProjectSummary() {
    final NumberFormat currencyFormat = NumberFormat.currency(
      locale: 'en_US',
      symbol: '',
      decimalDigits: 2,
    );

    return GFCard(
      boxFit: BoxFit.cover,
      titlePosition: GFPosition.start,
      showImage: true,
      title: GFListTile(
        titleText: 'Loyiha hisobotlari',
      ),
      content: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: DataTable(
          columns: [
            DataColumn(label: Text('т/р')),
            DataColumn(label: Text('Мижоз номи')),
            DataColumn(label: Text('Шартнома раками')),
            DataColumn(label: Text('Лизинг берилган сана')),
            DataColumn(label: Text('Лизингни сундириш муддати')),
            DataColumn(label: Text('Лизинг шартномаси суммаси')),
            DataColumn(
                label: Text('Лойиҳадаги мижознинг пул кўринишидаги улуши')),
            DataColumn(label: Text('Дастлабки лизинг колдиги суммаси')),
            DataColumn(label: Text('Хисобот кунига лизинг колдик суммаси')),
            DataColumn(label: Text('Лизинг объекти')),
            DataColumn(label: Text('Муддати утган лизинг танидан')),
            DataColumn(label: Text('Муддати утган Фоиздан')),
            DataColumn(label: Text('Пеня')),
            DataColumn(label: Text('МУДДАТИ УТГАН ЖАМИ КАРЗ')),
            DataColumn(label: Text('Мижоз рўйхатдан ўтган худуд')),
            DataColumn(label: Text('Мижоз телефон рақами')),
            DataColumn(label: Text('Мутахассиси')),
          ],
          rows: filteredList.map((project) {
            return DataRow(cells: [
              DataCell(Text((filteredList.indexOf(project) + 1).toString())),
              DataCell(Text(project['Мижоз номи'].toString())),
              DataCell(Text(project['Шартнома раками'].toString())),
              DataCell(Text(project['Лизинг берилган сана'].toString())),
              DataCell(Text(project['Лизингни сундириш муддати'].toString())),
              DataCell(Text(currencyFormat.format(double.tryParse(
                  project['Лизинг шартномаси суммаси'].toString()) ??
                  0))),
              DataCell(Text(currencyFormat.format(double.tryParse(
                  project['Лойиҳадаги мижознинг пул кўринишидаги улуши']
                      .toString()) ??
                  0))),
              DataCell(Text(currencyFormat.format(double.tryParse(
                  project['Дастлабки лизинг колдиги суммаси'].toString()) ??
                  0))),
              DataCell(Text(currencyFormat.format(double.tryParse(
                  project['Хисобот кунига лизинг колдик суммаси']
                      .toString()) ??
                  0))),
              DataCell(Text(project['Лизинг объекти'].toString())),
              DataCell(Text(currencyFormat.format(double.tryParse(
                  project['Муддати утган лизинг танидан'].toString()) ??
                  0))),
              DataCell(Text(currencyFormat.format(double.tryParse(
                  project['Муддати утган Фоиздан'].toString()) ??
                  0))),
              DataCell(Text(currencyFormat
                  .format(double.tryParse(project['Пеня'].toString()) ?? 0))),
              DataCell(Text(currencyFormat.format(double.tryParse(
                  project['МУДДАТИ УТГАН ЖАМИ КАРЗ'].toString()) ??
                  0))),
              DataCell(Text(project['Мижоз рўйхатдан ўтган худуд'].toString())),
              DataCell(Text(project['Мижоз телефон рақами'].toString())),
              DataCell(Text(project['Мутахассиси'].toString())),
            ]);
          }).toList(),
        ),
      ),
    );
  }

  void generateExcel() async {
    List<Map<dynamic, dynamic>> dataListToSave = showAllProjects
        ? filteredList
        : filteredList.where((client) {
      double jamiLizingTani = client['Жами лизинг таннархи'] is String
          ? double.tryParse(client['Жами лизинг таннархи']) ?? 0
          : client['Жами лизинг таннархи'] ?? 0;
      double penya = client['Пеня'] is String
          ? double.tryParse(client['Пеня']) ?? 0
          : client['Пеня'] ?? 0;
      double foizdan = client['Фоиздан'] is String
          ? double.tryParse(client['Фоиздан']) ?? 0
          : client['Фоиздан'] ?? 0;

      double jamiKarz = jamiLizingTani + penya + foizdan;

      return jamiKarz > 0;
    }).toList();

    // Create a new Excel document.
    final Workbook workbook = Workbook();
    final Worksheet sheet = workbook.worksheets[0];

    // Define the header style.
    final Style headerStyle = workbook.styles.add('HeaderStyle');
    headerStyle.fontName = 'Calibri';
    headerStyle.bold = true;
    headerStyle.hAlign = HAlignType.center;
    headerStyle.vAlign = VAlignType.center;
    headerStyle.borders.all.lineStyle = LineStyle.thin;

    // Define the number cell style.
    final Style numberCellStyle = workbook.styles.add('NumberCellStyle');
    numberCellStyle.hAlign = HAlignType.right;
    numberCellStyle.vAlign = VAlignType.center;
    numberCellStyle.numberFormat = '#,##0.00';
    numberCellStyle.borders.all.lineStyle = LineStyle.thin;

    // List of headers.
    List<String> headers = [
      'N',
      'Мижоз номи',
      'Шартнома раками',
      'Лизинг берилган сана',
      'Лизингни сундириш муддати',
      'Лизинг шартномаси суммаси',
      'Лойиҳадаги мижознинг пул кўринишидаги улуши',
      'Дастлабки лизинг колдиги суммаси',
      'Хисобот кунига лизинг колдик суммаси',
      'Лизинг объекти',
      'Муддати утган лизинг танидан',
      'Муддати утган Фоиздан',
      'Пеня',
      'МУДДАТИ УТГАН ЖАМИ КАРЗ',
      'Мижоз рўйхатдан ўтган худуд',
      'Мижоз телефон рақами',
      'Мутахассиси'
    ];

    // Set headers in the first row.
    for (int i = 0; i < headers.length; i++) {
      final cell = sheet.getRangeByIndex(1, i + 1);
      cell.setText(headers[i]);
      cell.cellStyle = headerStyle;
    }

    // Set data rows with counter in the "N" column.
    for (int row = 0; row < dataListToSave.length; row++) {
      // Set the counter in the "N" column (first column, index 0).
      final cellN = sheet.getRangeByIndex(row + 2, 1);
      cellN.setNumber(row + 1);
      cellN.cellStyle = headerStyle;

      final client = dataListToSave[row];
      for (int col = 1; col < headers.length; col++) { // Start from col=1 to skip "N"
        final cell = sheet.getRangeByIndex(row + 2, col + 1);
        var dataValue = client[headers[col]];
        if ([5, 6, 7, 8, 10, 11, 12, 13].contains(col)) {
          if (dataValue is num) {
            cell.setNumber(dataValue.toDouble());
            cell.cellStyle = numberCellStyle;
          } else if (dataValue is String) {
            double? value = double.tryParse(dataValue);
            if (value != null) {
              cell.setNumber(value);
              cell.cellStyle = numberCellStyle;
            } else {
              cell.setText('N/A');
            }
          }
        } else {
          cell.setText(dataValue?.toString() ?? '');
        }
        // Set border for the cell
        cell.cellStyle.borders.all.lineStyle = LineStyle.thin;
      }
    }


    // Auto-fit columns to make sure all data is visible.
    for (int i = 1; i <= headers.length; i++) {
      sheet.autoFitColumn(i);
    }

    // Save the document.
    final List<int> bytes = workbook.saveAsStream();
    workbook.dispose();

    if (kIsWeb) {
      // Web-specific code to create a downloadable file
      final content = base64Encode(bytes);
      final anchor = html.AnchorElement(
          href: 'data:application/octet-stream;base64,$content')
        ..setAttribute('download', 'Hisobot.xlsx')
        ..click();
    } else {
      // Save file to the device (non-web platforms).
      Directory directory = await getApplicationDocumentsDirectory();
      String filePath = '${directory.path}/Hisobot.xlsx';
      File(filePath)
        ..createSync(recursive: true)
        ..writeAsBytesSync(bytes);
    }
  }

  void _setFixedTotalValue(Worksheet sheet, int rowIndex, int colIndex, double value) {
    sheet.getRangeByIndex(rowIndex, colIndex).setNumber(value);
    sheet.getRangeByIndex(rowIndex, colIndex).cellStyle.bold = true;
  }
}