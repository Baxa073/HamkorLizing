import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:awesome_snackbar_content/awesome_snackbar_content.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hamkoroffline/dashbord_page.dart';
import 'package:hamkoroffline/pages/home_page.dart';
import 'package:lottie/lottie.dart';
import 'package:firebase_database/firebase_database.dart'; // Import Firebase Realtime Database

import 'super_admin.dart'; // SuperAdminProfilePage sahifasini import qilish
import '../Login/employee_dashboard_page.dart';


class LoginScreen extends StatelessWidget {
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Kirish',
            style: GoogleFonts.poppins(fontWeight: FontWeight.bold)),
        backgroundColor: Colors.green,
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => HomePage()),
            );
          },
        ),
      ),
      body: Stack(
        fit: StackFit.expand,
        children: [
          Image.asset(
            'assets/images/login2.jpg',
            fit: BoxFit.cover,
          ),
          Container(
            color: Colors.black.withOpacity(0.5),
          ),
          Center(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    'Xush Kelibsiz Hurmatli Xodim!',
                    style: GoogleFonts.poppins(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  SizedBox(height: 20),
                  buildTextField(emailController, 'Email', Icons.email, false),
                  SizedBox(height: 20),
                  buildTextField(passwordController, 'Parol', Icons.lock, true),
                  SizedBox(height: 30),
                  buildLoginButton(context),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget buildTextField(TextEditingController controller, String label,
      IconData icon, bool isPassword) {
    return TextField(
      controller: controller,
      obscureText: isPassword,
      style: TextStyle(color: Colors.white),
      decoration: InputDecoration(
        prefixIcon: Icon(icon, color: Colors.green),
        labelText: label,
        labelStyle: GoogleFonts.poppins(color: Colors.green),
        enabledBorder: OutlineInputBorder(
          borderSide: BorderSide(color: Colors.green),
          borderRadius: BorderRadius.circular(10),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: BorderSide(color: Colors.green),
          borderRadius: BorderRadius.circular(10),
        ),
      ),
    );
  }

  Widget buildLoginButton(BuildContext context) {
    return ElevatedButton(
      onPressed: () => _login(context),
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.green,
        padding: EdgeInsets.symmetric(horizontal: 50, vertical: 15),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
      ),
      child: Text(
        'Kirish',
        style: GoogleFonts.poppins(
          fontSize: 18,
          fontWeight: FontWeight.bold,
          color: Colors.white,
        ),
      ),
    );
  }

  void _login(BuildContext context) async {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => Center(
        child: Lottie.asset(
          'assets/animations/employee_profile.json',
          width: 200,
          height: 200,
          fit: BoxFit.cover,
        ),
      ),
    );

    try {
      UserCredential userCredential = await FirebaseAuth.instance
          .signInWithEmailAndPassword(
          email: emailController.text, password: passwordController.text);

      // Fetch user role from Firebase Realtime Database
      String uid = userCredential.user!.uid;
      DatabaseReference roleRef =
      FirebaseDatabase.instance.ref().child('profiles/$uid/role');
      DatabaseEvent event = await roleRef.once();
      String role = event.snapshot.value as String? ?? '';

      Navigator.pop(context); // Close the loading animation

      if (role == 'Bosh Direktor') {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => AdminDashboardPage()),
        );
      } else if (role == 'SuperAdmin') {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => SuperAdminProfilePage()),
        );
      } else {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
              builder: (context) =>
                  EmployeeDashboardPage(user: userCredential.user!)),
        );
      }
    } catch (e) {
      Navigator.pop(context); // Close the loading animation
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          behavior: SnackBarBehavior.floating,
          content: AwesomeSnackbarContent(
            title: 'Xatolik',
            message: 'Kirishda xatolik: ${e.toString()}',
            contentType: ContentType.failure,
          ),
        ),
      );
    }
  }
}
