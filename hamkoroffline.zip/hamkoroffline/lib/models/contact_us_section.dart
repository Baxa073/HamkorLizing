import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';
import 'package:responsive_builder/responsive_builder.dart';
import 'package:url_launcher/url_launcher.dart';

class ContactUsSection extends StatelessWidget {
  final double fontSizeMultiplier;
  final Animation<Offset> slideAnimation;
  final Animation<double> opacityAnimation;

  const ContactUsSection({
    required this.fontSizeMultiplier,
    required this.slideAnimation,
    required this.opacityAnimation,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0),
      child: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.green.shade100!, Colors.white],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.5),
              spreadRadius: 5,
              blurRadius: 7,
              offset: Offset(0, 3), // changes position of shadow
            ),
          ],
        ),
        child: ResponsiveBuilder(
          builder: (context, sizingInformation) {
            bool isMobile = sizingInformation.isMobile;

            return Padding(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (!isMobile)
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(
                          flex: 1,
                          child: SlideTransition(
                            position: slideAnimation,
                            child: FadeTransition(
                              opacity: opacityAnimation,
                              child: Lottie.asset(
                                'assets/animations/contact.json',
                                width: 500,
                                height: 500,
                                fit: BoxFit.contain,
                              ),
                            ),
                          ),
                        ),
                        SizedBox(width: 20),
                        Expanded(
                          flex: 1,
                          child: _buildContactDetails(fontSizeMultiplier),
                        ),
                      ],
                    ),
                  if (isMobile)
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SlideTransition(
                          position: slideAnimation,
                          child: FadeTransition(
                            opacity: opacityAnimation,
                            child: Lottie.asset(
                              'assets/animations/contact.json',
                              width: 300,
                              height: 300,
                              fit: BoxFit.contain,
                            ),
                          ),
                        ),
                        SizedBox(height: 20),
                        _buildContactDetails(fontSizeMultiplier, isMobile: true),
                      ],
                    ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _buildContactDetails(double fontSizeMultiplier, {bool isMobile = false}) {
    double leftPadding = isMobile ? 0.0 : 50.0;
    double topPadding = isMobile ? 0.0 : 100.0;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: EdgeInsets.only(left: leftPadding, top: topPadding),
          child: Text(
            'Biz bilan aloqa',
            style: TextStyle(
              fontSize: 32 * fontSizeMultiplier,
              fontWeight: FontWeight.bold,
              color: Colors.green.shade800,
              shadows: [
                Shadow(
                  blurRadius: 10.0,
                  color: Colors.black26,
                  offset: Offset(3.0, 3.0),
                ),
              ],
            ),
          ),
        ),
        SizedBox(height: 30),
        _buildContactRow(
          icon: Icons.phone,
          label: 'TELEFON RAQAM:',
          leftPadding: leftPadding,
          fontSizeMultiplier: fontSizeMultiplier,
          color: Colors.green.shade700,
        ),
        Padding(
          padding: EdgeInsets.only(left: leftPadding),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildContactText('+998 (95) 307-70-10'),
              _buildContactText('+998 (95) 308-70-10'),
              _buildContactText('+998 (95) 309-70-10'),
            ],
          ),
        ),
        SizedBox(height: 20),
        _buildContactRow(
          icon: Icons.telegram,
          label: 'Telegram',
          leftPadding: leftPadding,
          fontSizeMultiplier: fontSizeMultiplier,
          color: Colors.blue.shade700,  // Blue color for Telegram
        ),
        Padding(
          padding: EdgeInsets.only(left: leftPadding),
          child: GestureDetector(
            onTap: () async {
              const url = 'https://t.me/hamkorlizingorg';
              await _launchURL(url);
            },
            child: Text(
              '@HamkorLizingorg',
              style: TextStyle(
                fontSize: 18 * fontSizeMultiplier,
                color: Colors.blue.shade700,
                decoration: TextDecoration.underline,
              ),
            ),
          ),
        ),
        SizedBox(height: 20),
        _buildContactRow(
          icon: Icons.location_on,
          label: 'Manzil',
          leftPadding: leftPadding,
          fontSizeMultiplier: fontSizeMultiplier,
          color: Colors.red.shade700,  // Red color for location
        ),
        Padding(
          padding: EdgeInsets.only(left: leftPadding),
          child: GestureDetector(
            onTap: () async {
              const url = 'https://yandex.uz/maps/-/CDguMKmr';
              await _launchURL(url);
            },
            child: Text(
              'Toshkent shahar, Sergeli tumani, Sergeli-VIII massivi, 2-uy',
              style: TextStyle(
                fontSize: 18 * fontSizeMultiplier,
                color: Colors.red.shade700,
                decoration: TextDecoration.underline,
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildContactRow({
    required IconData icon,
    required String label,
    required double leftPadding,
    required double fontSizeMultiplier,
    required Color color,
  }) {
    return Padding(
      padding: EdgeInsets.only(left: leftPadding),
      child: Row(
        children: [
          Icon(icon, color: color, size: 26 * fontSizeMultiplier),  // Icon size adjusted
          SizedBox(width: 12),
          Text(
            label,
            style: TextStyle(
              fontSize: 22 * fontSizeMultiplier,
              fontWeight: FontWeight.bold,
              color: color,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildContactText(String text) {
    return Text(
      text,
      style: TextStyle(
        fontSize: 18 * fontSizeMultiplier,
        color: Colors.black87,
        height: 1.5,
      ),
    );
  }

  Future<void> _launchURL(String url) async {
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      throw 'Could not launch $url';
    }
  }
}
