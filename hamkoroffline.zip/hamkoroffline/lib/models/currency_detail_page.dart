import 'package:flutter/material.dart';
import 'currency_service.dart';

class CurrencyDetailPage extends StatelessWidget {
  final List<CurrencyRate> rates;

  const CurrencyDetailPage({
    Key? key,
    required this.rates,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Valyuta Kurslari'),
        backgroundColor: Colors.green,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Valyuta kurslari:  ${DateTime.now().toLocal()}',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 20),
            Expanded(
              child: ListView.builder(
                itemCount: rates.length,
                itemBuilder: (context, index) {
                  var rate = rates[index];
                  return Card(
                    child: Padding(
                      padding: const EdgeInsets.all(12.0),
                      child: Row(
                        children: [
                          Image.asset(
                            'assets/flags/${rate.currencyCode}.png',
                            width: 40,
                            height: 30,
                            errorBuilder: (context, error, stackTrace) =>
                                Icon(Icons.flag),
                          ),
                          SizedBox(width: 10),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  '${rate.currencyCode} - ${rate.currencyCode}',
                                  style: TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                SizedBox(height: 5),
                                Text(
                                  'Markaziy Bank Kursi: ${rate.cbRate.toStringAsFixed(2)}',
                                  style: TextStyle(fontSize: 16),
                                ),
                                Text(
                                  'Sotib olish: ${rate.buyRate.toStringAsFixed(2)}',
                                  style: TextStyle(fontSize: 16),
                                ),
                                Text(
                                  'Sotish: ${rate.sellRate.toStringAsFixed(2)}',
                                  style: TextStyle(fontSize: 16),
                                ),
                              ],
                            ),
                          ),
                          Row(
                            children: [
                              Icon(
                                rate.isUp
                                    ? Icons.arrow_upward
                                    : Icons.arrow_downward,
                                color: rate.isUp ? Colors.green : Colors.red,
                              ),
                              Text(
                                '${rate.change.toStringAsFixed(2)}',
                                style: TextStyle(
                                  color: rate.isUp
                                      ? Colors.green
                                      : Colors.red,
                                  fontSize: 16,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
