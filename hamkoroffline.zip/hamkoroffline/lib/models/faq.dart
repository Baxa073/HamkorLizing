import 'package:flutter/material.dart';

class FAQSection extends StatelessWidget {
  final List<Map<String, String>> faqList = [
    {
      'question': 'Lizingga olinadigan vositalarning egalik huquqi kimning nomiga rasmiylashtiriladi?',
      'answer': 'Lizingga olinadigan vositalarning egalik huquqi lizing kompaniyasi nomida bo‘ladi va lizing shartnomasi muddati tugaganidan keyin lizing oluvchi mijoz nomiga egalik huquqi bilan rasmiylashtiriladi.',
    },
    {
      'question': 'Olingan lizing summasini muddatidan oldin yopish mumkinmi?',
      'answer': 'Lizing kamida 12 oy muddatga ajratiladi. Lizing olinganidan keyin 12 oy o‘tib lizing oluvchi to‘liq yopishi va lizing ob’ektini nomiga rasmiylashtirib olishi mumkin.',
    },
    {
      'question': 'Qanday faoliyat turlariga lizing ajratilmaydi va lizing ob’ektiga qanday talablar mavjud?',
      'answer': 'Likyor-aroq mahsulotlari ishlab chiqarish; tamaki mahsulotlari ishlab chiqarish bilan bog‘liq loyihalarni; qimor biznesiga qaratilgan loyihalarni moliyalashtirilmaydi; Shuningdek, ishlatilgan asbob-uskunalar, 7 yildan oshgan eski qayta tiklangan uskunalar va 5 yildan oshgan eski avtotransport va ixtisoslashtirilgan texnika bilan bog‘liq loyihalar moliyalashtirilmaydi.',
    },
    {
      'question': 'Qaytariladigan lizing nima?',
      'answer': 'Lizing oluvchining o‘ziga tegishli bo‘lgan (lizing ob’ekti bo‘la oladigan) mol – mulkini Lizing kompaniyasiga sotib, uni ma’lum shartlar asosida lizing shartnomasi muddati oxirida qayta o‘ziniki qilib olish sharti bilan lizing hisobiga olishi qaytariladigan lizing deyiladi.',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: EdgeInsets.symmetric(vertical: 16),
            decoration: BoxDecoration(
              border: Border(
                bottom: BorderSide(color: Colors.green.shade800, width: 2),
              ),
            ),
            child: Text(
              'Ko\'p beriladigan savollar',
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.bold,
                color: Colors.green.shade900,
                shadows: [
                  Shadow(
                    blurRadius: 10.0,
                    color: Colors.black45,
                    offset: Offset(2.0, 2.0),
                  ),
                ],
              ),
            ),
          ),
          SizedBox(height: 16),
          ...faqList.map((faq) => _buildFAQItem(faq)).toList(),
        ],
      ),
    );
  }

  Widget _buildFAQItem(Map<String, String> faq) {
    return Card(
      elevation: 8,
      margin: EdgeInsets.only(bottom: 16),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      shadowColor: Colors.black45,
      child: ExpansionTile(
        tilePadding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        collapsedBackgroundColor: Colors.green.shade50,
        backgroundColor: Colors.green.shade100,
        title: Text(
          faq['question']!,
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w600,
            color: Colors.green.shade900,
          ),
        ),
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
            child: Text(
              faq['answer']!,
              style: TextStyle(fontSize: 16, color: Colors.black87, height: 1.5),
            ),
          ),
        ],
      ),
    );
  }
}
