import 'package:flutter/material.dart';
import 'package:hamkoroffline/Login/super_admin.dart';

import 'package:hamkoroffline/cars/AllProductsPage.dart';
import 'package:hamkoroffline/dashbord_page.dart';
import 'package:responsive_builder/responsive_builder.dart';
import '../pages/home_page.dart';
import 'leasing_calculator.dart';
import '../Login/employee_dashboard_page.dart';
import '../Login/login_screen.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'leasing_services_page.dart';
import 'meyory_hujjat.dart';

class CustomNavBar extends StatelessWidget implements PreferredSizeWidget {
  final VoidCallback? onDrawerIconPressed;

  CustomNavBar({this.onDrawerIconPressed});

  @override
  Widget build(BuildContext context) {
    return ResponsiveBuilder(
      builder: (context, sizingInformation) {
        bool isMobile = sizingInformation.isMobile;

        return AppBar(
          automaticallyImplyLeading: false, // Prevents the default drawer icon
          backgroundColor: Colors.white,
          elevation: 4.0,
          shadowColor: Colors.black.withOpacity(0.2),
          title: GestureDetector(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => HomePage()),
              );
            },
            child: Image.asset(
              'assets/images/Logo__1.png',
              height: 50,
            ),
          ),
          actions: !isMobile
              ? _buildNavButtons(context) // Display buttons for desktop/tablet
              : [
            IconButton(
              icon: Icon(Icons.menu, color: Colors.green),
              onPressed: onDrawerIconPressed ?? () {}, // Handle drawer icon press
            ),
          ],
        );
      },
    );
  }

  Future<Widget> _determineDestination() async {
    User? currentUser = FirebaseAuth.instance.currentUser;

    if (currentUser == null) {
      return LoginScreen();
    }

    String email = currentUser.email?.toLowerCase() ?? '';
    final roleRef = FirebaseDatabase.instance
        .ref()
        .child('profiles/${currentUser.uid}/role');

    final DatabaseEvent event = await roleRef.once();
    final String role = event.snapshot.value as String? ?? '';

    if (role == 'SuperAdmin' || email == 'buxorovbahodir11@gmail.com') {
      return SuperAdminProfilePage();
    } else if (role == 'Bosh Direktor') {
      return AdminDashboardPage();
    } else {
      return EmployeeDashboardPage(user: currentUser);
    }
  }

  List<Widget> _buildNavButtons(BuildContext context) {
    return [
      _buildNavButton(
        context,
        title: 'Barcha mahsulotlar',
        destination: AllProductsPage(categoryTitle: 'Barcha Mahsulotlar'),
        icon: Icons.directions_car,
      ),

      _buildNavButton(
        context,
        title: 'Lizing kalkulyator',
        destination: LeasingOptionsPage(),
        icon: Icons.calculate,
      ),
      _buildNavButton(
        context,
        title: 'Xizmatlarimiz',
        destination: LeasingServicesPage(),
        icon: Icons.business_center,
      ),
      _buildNavButton(
        context,
        title: 'Me\'yoriy hujjatlar',
        destination: MeyoriyHujjatlarPage(),
        icon: Icons.file_copy,
      ),
      FutureBuilder<Widget>(
        future: _determineDestination(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Padding(
              padding: const EdgeInsets.all(8.0),
              child: CircularProgressIndicator(),
            );
          } else if (snapshot.hasError) {
            return Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text('Error: ${snapshot.error}'),
            );
          } else if (snapshot.hasData && FirebaseAuth.instance.currentUser != null) {
            return _buildNavButton(
              context,
              title: 'Shaxsiy hisobim',
              destination: snapshot.data!,
              icon: Icons.account_circle,
            );
          } else if (FirebaseAuth.instance.currentUser == null) {
            return _buildNavButton(
              context,
              title: 'Kirish',
              destination: LoginScreen(),
              icon: Icons.login,
            );
          } else {
            return _buildNavButton(
              context,
              title: 'Shaxsiy hisobim',
              destination: LoginScreen(),
              icon: Icons.account_circle,
            );
          }
        },
      ),
    ];
  }

  Widget _buildNavButton(BuildContext context,
      {required String title, required Widget destination, required IconData icon}) {
    return TextButton.icon(
      onPressed: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => destination),
        );
      },
      icon: Icon(icon, color: Colors.green),
      label: Text(
        title,
        style: TextStyle(
          color: Colors.green,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  @override
  Size get preferredSize => Size.fromHeight(kToolbarHeight);
}
