import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:responsive_builder/responsive_builder.dart';
import '../cars/AllProductsPage.dart';
import '../pages/home_page.dart';
import 'leasing_calculator.dart';
import 'meyory_hujjat.dart';
import 'nav_bar.dart'; // Import your CustomNavBar

void main() {
  runApp(MaterialApp(
    home: LeasingServicesPage(),
    theme: ThemeData(
      primarySwatch: Colors.blue,
      fontFamily: 'Roboto',
    ),
  ));
}

class LeasingServicesPage extends StatefulWidget {
  @override
  _LeasingServicesPageState createState() => _LeasingServicesPageState();
}

class _LeasingServicesPageState extends State<LeasingServicesPage> {
  String selectedCategory = 'Lizing';
  bool isTapped = false;
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  final Map<String, List<Map<String, dynamic>>> categoryData = {
    'Lizing': [
      {
        'title': 'Lizing faoliyati',
        'description':
        'Lizing faoliyati — lizing beruvchi tomonidan oʻz mablagʻlari va (yoki) jalb etilgan mablagʻlar hisobidan lizing obyektining sotib olinishi va uni lizing shartnomasi asosida lizing oluvchiga berilishi borasidagi faoliyat turidir.',
        'icon': Icons.attach_money,
      },
      {
        'title': 'Lizing (moliyaviy ijara)',
        'description':
        'Lizing (moliyaviy ijara) — bir taraf (lizing beruvchi) ikkinchi tarafning (lizing oluvchining) topshirigʻiga binoan uchinchi tarafdan (sotuvchidan) lizing obyektini mulk qilib sotib olishni va uni haq evaziga 12 oydan ortiq muddatga berishni nazarda tutadigan ijara munosabatlarining alohida turi.',
        'icon': Icons.business_center,
      },
      {
        'title': 'Lizing obyektlari',
        'description':
        'Lizing obyektlari — tadbirkorlik faoliyati uchun foydalaniladigan isteʼmol qilinmaydigan har qanday ashyolar, korxonalar, mulkiy komplekslar, binolar, transport vositalari va koʻchmas mulklar lizing obyektlari hisoblanadi.',
        'icon': Icons.local_mall,
      },
      {
        'title': 'Lizing subyektlari',
        'description':
        'Lizing subyektlari — lizing beruvchi, lizing oluvchi hamda sotuvchi.',
        'icon': Icons.group,
      },
    ],
    'Ijara': [
      {
        'title': 'Operativ Ijara',
        'description':
        'Operativ ijara — bu moliyaviy ijara shartnomasi xisoblanmaydigan mulk ijara shartnomasiga muvofiq mulkni vaqtinchalik egalik qilish yoki foydalanishga berilishi boʻyicha ijara munosabatlari.',
        'icon': Icons.local_shipping,
      },
      {
        'title': 'Ijara shartnomasi',
        'description':
        'Ijara shartnomasi — ijaraga beruvchi ijaraga oluvchiga ma\'lum haq evaziga ijara obyektini vaqtinchalik egalik qilish va foydalanish uchun berish majburiyatini oluvchi yozma bitim. Moliyaviy ijara munosabatlari tuziladigan ijara shartnomalarida shartnoma muddati tugagandan so\'ng ijara obyektini ijaraga oluvchining egaligiga o\'tishi, operativ ijara boʻyicha tuziladigan ijara shartnomalarida esa shartnoma muddati tugagandan so\'ng ijara obyektini ijaraga beruvchining ixtiyorida qolishi belgilab qo\'yiladi.',
        'icon': Icons.article,
      },
      {
        'title': 'Moliyaviy ijara munosabatlari obyektlari',
        'description':
        'Ijara obyektini ijaraga oluvchiga topshirish paytiga qadar ijaraga beruvchida mulk xuquqi sifatida shakllangan iste\'mol qilinmaydigan quyidagi obyektlar moliyaviy ijara munosabatlari obyektlari hisoblanadi: a) yangi ishlab chiqarilgan yoki ishlab chiqarilganiga 10 yildan ko\'p vaqt bo\'lmagan avval foydalanishda bo\'lgan yengil va yuk tashuvchi avtotransport vositalari; b) yangi ishlab chiqarilgan yoki ishlab chiqarilganiga 5 yildan ko\'p vaqt bo\'lmagan qishloq xo\'jaligi hamda maxsus texnikalar; s) buzishga tushmagan (snos) noturar bino va inshootlar.',
        'icon': Icons.construction,
      },
      {
        'title': 'Operativ ijara munosabatlari obyektlari',
        'description':
        '“Hamkorbank” ATB ishtirokidagi lizing kompaniyalari balanslaridagi ko’chmas mulklar, biznes markazlaridagi ofis xonalari, o’quv zallari, restoran, oshxona va ijara munosabatlarining qonunchilik talablaridan kelib chiqqan holda ta’qiqlanmagan, operativ ijaraga berish mumkin bo’lgan ijara obyektlari.',
        'icon': Icons.location_city,
      },
      {
        'title': 'Ijara munosabatlari subyektlari',
        'description': 'Ijara munosabatlari subyektlari — ijaraga beruvchi va ijaraga oluvchi.',
        'icon': Icons.group,
      },
      {
        'title': 'Ijaraga beruvchi',
        'description':
        '“Hamkorbank” ATB ishtirokidagi ijara obyektini ijaraga berish huquqiga ega bo’lgan lizing kompaniyalari.',
        'icon': Icons.business,
      },
      {
        'title': 'Ijaraga oluvchi',
        'description':
        'Ijara shartnomasiga asosan ijara obyektlarini ma\'lum haq evaziga muddatli egalik qilish va undan foydalanuvchi yuridik shaxslar, yakka tartibdagi tadbirkorlar va jismoniy shaxslar. Moliyaviy ijara munosabatlarida ijaraga oluvchi ijara shartnomasi muddati tugagandan so\'ng ijara obyektini o\'z egaligiga olishi ijara shartnomasida nazarda tutilishi lozim.',
        'icon': Icons.person,
      },
    ],
  };

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      appBar: CustomNavBar(
        onDrawerIconPressed: () {
          _scaffoldKey.currentState?.openDrawer();
        },
      ),
      drawer: _buildDrawer(context),
      body: SingleChildScrollView(  // Scrollable content
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildCategoryButtons(),
              SizedBox(height: 20),
              _buildPieChart(), // Pie chart scrolls with the rest
              SizedBox(height: 20),
              _buildServiceGrid(), // Grid of service cards
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildServiceGrid() {
    return ResponsiveBuilder(
      builder: (context, sizingInformation) {
        bool isMobile = sizingInformation.isMobile;
        return GridView.builder(
          physics: NeverScrollableScrollPhysics(), // Disable scrolling of GridView
          shrinkWrap: true, // Allow GridView to shrink within the column
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: isMobile ? 1 : 2,
            crossAxisSpacing: 20.0,
            mainAxisSpacing: 20.0,
            childAspectRatio: isMobile ? 1 : 1.5,
          ),
          itemCount: categoryData[selectedCategory]!.length,
          itemBuilder: (context, index) {
            final service = categoryData[selectedCategory]![index];
            return GestureDetector(
              onTap: () {
                setState(() {
                  isTapped = !isTapped;
                });
              },
              child: AnimatedContainer(
                duration: Duration(milliseconds: 300),
                transform: Matrix4.identity()..scale(isTapped ? 1.05 : 1.0),
                child: buildServiceCard(
                  service['title'],
                  service['description'],
                  service['icon'],
                ),
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildDrawer(BuildContext context) {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: <Widget>[
          DrawerHeader(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Color(0xFF1B5E20), Color(0xFF4CAF50)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
            child: Text(
              'Hamkor Lizing',
              style: TextStyle(
                color: Colors.white,
                fontSize: 24,
                fontWeight: FontWeight.bold,
                shadows: [
                  Shadow(
                    blurRadius: 10.0,
                    color: Colors.black45,
                    offset: Offset(2.0, 2.0),
                  ),
                ],
              ),
            ),
          ),
          _buildNavButton(
            context,
            title: 'Bosh sahifa',
            destination: HomePage(), // Your HomePage Widget
            icon: Icons.home,
          ),
          _buildNavButton(
            context,
            title: 'Barcha Mahsulotlar',
            destination: AllProductsPage(categoryTitle: 'Barcha Mahsulotlar'), // Your AllProductsPage Widget
            icon: Icons.directions_car,
          ),
          _buildNavButton(
            context,
            title: 'Xizmatlar',
            destination: LeasingServicesPage(),
            icon: Icons.business_center,
          ),
          _buildNavButton(
            context,
            title: 'Lizing Kalkulyator',
            destination: LeasingOptionsPage(), // Your LeasingOptionsPage Widget
            icon: Icons.calculate,
          ),
          _buildNavButton(
            context,
            title: 'Me\'yoriy Hujjatlar',
            destination: MeyoriyHujjatlarPage(), // Your MeyoriyHujjatlarPage Widget
            icon: Icons.file_copy,
          ),
        ],
      ),
    );
  }

  Widget _buildNavButton(BuildContext context, {required String title, required Widget destination, required IconData icon}) {
    return ListTile(
      leading: Icon(icon, color: Color(0xFF1B5E20)),
      title: Text(
        title,
        style: TextStyle(
          color: Colors.black87,
          fontWeight: FontWeight.w600,
        ),
      ),
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => destination),
        );
      },
    );
  }

  Widget _buildCategoryButtons() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        _buildStyledButton(
          label: 'Lizing',
          isSelected: selectedCategory == 'Lizing',
          onPressed: () {
            setState(() {
              selectedCategory = 'Lizing';
            });
          },
        ),
        SizedBox(width: 10),
        _buildStyledButton(
          label: 'Operativ Ijara',
          isSelected: selectedCategory == 'Ijara',
          onPressed: () {
            setState(() {
              selectedCategory = 'Ijara';
            });
          },
        ),
      ],
    );
  }

  Widget _buildStyledButton({required String label, required bool isSelected, required VoidCallback onPressed}) {
    return GestureDetector(
      onTap: onPressed,
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 20, vertical: 15),
        decoration: BoxDecoration(
          color: isSelected ? Colors.green : Colors.grey[300],
          borderRadius: BorderRadius.circular(25),
        ),
        child: Text(
          label,
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
            color: isSelected ? Colors.white : Colors.black,
          ),
        ),
      ),
    );
  }

  Widget buildServiceCard(String title, String description, IconData icon) {
    return Card(
      elevation: 10,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: AnimatedContainer(
        duration: Duration(milliseconds: 500),
        padding: EdgeInsets.all(20),
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: [Colors.green[400]!, Colors.blue[400]!]),
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(color: Colors.black12, blurRadius: 8, offset: Offset(0, 4)),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, size: 40, color: Colors.white),
            SizedBox(height: 20),
            Text(title, style: TextStyle(fontSize: 24, color: Colors.white, fontWeight: FontWeight.bold)),
            SizedBox(height: 10),
            Text(description, style: TextStyle(fontSize: 16, color: Colors.white70)),
          ],
        ),
      ),
    );
  }

  Widget _buildPieChart() {
    return Column(
      children: [
        Center(
          child: SizedBox(
            height: 220, // Adjusted height for pie chart
            child: PieChart(
              PieChartData(
                sections: showingSections(),
                centerSpaceRadius: 50, // Adjusted center space for a cleaner look
                sectionsSpace: 4, // Slightly increased space between sections
                borderData: FlBorderData(show: false),
              ),
            ),
          ),
        ),
        SizedBox(height: 20), // Space between chart and text info
        _buildPieChartInfo(), // Pie chart info below the chart
      ],
    );
  }

  Widget _buildPieChartInfo() {
    final int totalCustomers = 1200; // Total number of customers
    final int lizingCustomers = (totalCustomers * 0.55).toInt(); // 55% Lizing
    final int ijaraCustomers = (totalCustomers * 0.25).toInt(); // 25% Ijara
    final int operativIjaraCustomers = (totalCustomers * 0.20).toInt(); // 20% Operativ Ijara

    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Text(
          '55% Lizing - $lizingCustomers mijoz',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
        Text(
          '25% Ijara - $ijaraCustomers mijoz',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
        Text(
          '20% Operativ Ijara - $operativIjaraCustomers mijoz',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
        Text(
          'Mijozlar soni: 1200+',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.grey),
        ),
      ],
    );
  }

  List<PieChartSectionData> showingSections() {
    return List.generate(3, (i) {
      final fontSize = 14.0; // Reduced font size to fit text inside sections
      final radius = 70.0; // Adjusted radius for better section size
      final titleColor = Colors.white; // Ensure text is visible over sections

      switch (i) {
        case 0:
          return PieChartSectionData(
            color: Colors.green,
            value: 55, // 55% for Lizing
            title: '55% ',
            radius: radius,
            titleStyle: TextStyle(
              fontSize: fontSize,
              fontWeight: FontWeight.bold,
              color: titleColor,
            ),
            showTitle: true, // Keep the title inside the section
          );
        case 1:
          return PieChartSectionData(
            color: Colors.blueAccent,
            value: 25, // 25% for Ijara
            title: '25% ',
            radius: radius,
            titleStyle: TextStyle(
              fontSize: fontSize,
              fontWeight: FontWeight.bold,
              color: titleColor,
            ),
            showTitle: true, // Keep the title inside the section
          );
        case 2:
          return PieChartSectionData(
            color: Colors.deepOrangeAccent,
            value: 20, // 20% for Operativ Ijara
            title: '20%',
            radius: radius,
            titleStyle: TextStyle(
              fontSize: fontSize,
              fontWeight: FontWeight.bold,
              color: titleColor,
            ),
            showTitle: true, // Keep the title inside the section
          );
        default:
          throw Error();
      }
    });
  }

}
