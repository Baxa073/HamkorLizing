import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class BranchAddressesSection extends StatelessWidget {
  final double fontSizeMultiplier;

  const BranchAddressesSection({
    required this.fontSizeMultiplier,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(20.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Hamkor Lizing filiallari',
            style: TextStyle(
              color: Colors.green[900],
              fontSize: 36.0 * fontSizeMultiplier,
              fontWeight: FontWeight.bold,
              shadows: [
                Shadow(
                  blurRadius: 10.0,
                  color: Colors.grey.withOpacity(0.5),
                  offset: Offset(3.0, 3.0),
                ),
              ],
            ),
          ),
          SizedBox(height: 20),
          ..._buildBranchCards(context),
        ],
      ),
    );
  }

  List<Widget> _buildBranchCards(BuildContext context) {
    return [
      _buildBranchCard(
        context,
        'Toshkent shahri bosh ofis',
        'Toshkent shahri., Sergeli tumani, Sergeli-VIII massivi, 2-uy',
        'https://yandex.uz/maps/-/CDguMKmr',
        'Hamkorlizing” kompaniyasi Toshkent Bosh ofisi\n'
            'Manzil: Toshkent shahri, Sergeli tumani, Yangi Sergeli mavzesi, 8 – muyulish, 2 – uy.\n'
            'Lizing bo‘lim boshlig‘i: Aliqulov Abdukarim Abdukamalovich\n'
            'Telefon raqami: +998977243600',
        '+998977243600',
      ),
      SizedBox(height: 15),
      _buildBranchCard(
        context,
        'Buxoro viloyat filiali',
        'Buxoro shahar, Qayum Murtazoyev, 5',
        'https://yandex.uz/maps/-/CDgYqF2O',
        '“Hamkorlizing” kompaniyasi Buxoro filiali\n'
            'Manzil: Buxoro shahri, Qayum Murtazoev ko‘chasi, 5 – uy.\n'
            'Lizing xodimi: Toshqinov Baxrus Buxorovich\n'
            'Telefon raqami: +998914057542',
        '+998914057542',
      ),
      SizedBox(height: 15),
      _buildBranchCard(
        context,
        'Samarqand viloyat filiali',
        'Samarqand shahri, Maxmud Qoshg‘ariy ko‘chasi, 54 – uy',
        'https://maps.windows.com/?form=WNAMSH&collection=point.39.655465_66.95165_Point',
        '“Hamkorlizing” kompaniyasi Samarqand filiali\n'
            'Manzil: Samarqand shahri, Maxmud Qoshg‘ariy ko‘chasi, 54 – uy.\n'
            'Lizing xodimi: Kuzibayev Feruz Ochilovich\n'
            'Telefon raqami: +998902131341',
        '+998902131341',
      ),
      SizedBox(height: 15),
      _buildBranchCard(
        context,
        'Andijon viloyat filiali',
        'Andijon shahar, 3-kichik daha, 16 a uy',
        'https://maps.windows.com/?form=WNAMSH&collection=point.40.783862_72.331567_Point',
        '“Hamkorlizing” kompaniyasi Andijon1 filiali\n'
            'Manzil: Andijon shahar, 3-kichik daha, 16 a uy.\n'
            'Lizing xodimi: Sobirov Barkamol\n'
            'Telefon raqami: +998944305005, +998335005412',
        '+998944305005',
      ),

      SizedBox(height: 15),
      _buildBranchCard(
        context,
        'Qashqadaryo viloyat filiali',
        'Qarshi shahri, I.Karimov ko‘chasi, 52a – uy.',
        'https://g.co/kgs/xLPNJvv',
        '“Hamkorlizing” kompaniyasi Qarshi filiali\n'
            'Manzil: Qarshi shahri, I.Karimov ko‘chasi, 52a – uy.\n'
            'Lizing xodimi: Ernazarov Asqarali Nurmamatovich\n'
            'Telefon raqami: +998976767676',
        '+998976767676',
      ),
      SizedBox(height: 15),
      _buildBranchCard(
        context,
        'Namangan viloyat filiali',
        'Namangan shahri, Amir Temur ko‘chasi',
        'https://maps.windows.com/?form=WNAMSH&collection=point.40.99468_71.634575_Point',
        '“Hamkorlizing” kompaniyasi Namangan filiali\n'
            'Manzil: Namangan shahri, Amir Temur ko‘chasi.\n'
            'Lizing xodimi: Musaev Ravshan Xamzaalievich\n'
            'Telefon raqami: +998972560110',
        '+998972560110',
      ),
      SizedBox(height: 15),
      _buildBranchCard(
        context,
        'Farg\'ona viloyat filiali',
        'Farg\'ona shahar, B.Marg‘iloniy ko‘chasi 66 B uy',
        'https://maps.windows.com/?form=WNAMSH&collection=point.40.99468_71.634575_Point',
        '“Hamkorlizing” kompaniyasi Farg\'ona filiali\n'
            'Manzil: Farg\'ona shahar, B.Marg‘iloniy ko‘chasi 66 B uy.\n'
            'Lizing xodimi: Roziqov Bahodirjon To‘xtasinovich\n'
            'Telefon raqami: +998916790595',
        '+998916790595',
      ),
    ];
  }

  Widget _buildBranchCard(
      BuildContext context,
      String region,
      String address,
      String url,
      String detailedInfo,
      String phoneNumber,
      ) {
    return GestureDetector(
      onTap: () => _showBranchInfoDialog(context, region, detailedInfo, url, phoneNumber),
      child: Card(
        elevation: 8,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [Colors.green[100]!, Colors.green[300]!],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.5),
                spreadRadius: 3,
                blurRadius: 7,
                offset: Offset(0, 3), // changes position of shadow
              ),
            ],
          ),
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Row(
              children: [
                Icon(
                  Icons.location_city,
                  color: Colors.green[900],
                  size: 50.0 * fontSizeMultiplier,
                ),
                SizedBox(width: 20),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        region,
                        style: TextStyle(
                          fontSize: 24.0 * fontSizeMultiplier,
                          fontWeight: FontWeight.bold,
                          color: Colors.green[900],
                        ),
                      ),
                      SizedBox(height: 5),
                      Text(
                        address,
                        style: TextStyle(
                          fontSize: 18.0 * fontSizeMultiplier,
                          color: Colors.black87,
                        ),
                      ),
                    ],
                  ),
                ),
                Icon(
                  Icons.arrow_forward_ios,
                  color: Colors.green[900],
                  size: 24.0 * fontSizeMultiplier,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _showBranchInfoDialog(
      BuildContext context,
      String region,
      String detailedInfo,
      String url,
      String phoneNumber,
      ) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(
            region,
            style: TextStyle(
              fontWeight: FontWeight.bold,
              color: Colors.green[900],
            ),
          ),
          content: Text(detailedInfo),
          actions: [
            TextButton(
              child: Text(
                'Qo\'ng\'iroq qilish',
                style: TextStyle(color: Colors.green[900]),
              ),
              onPressed: () => _makePhoneCall(phoneNumber, context),
            ),
            TextButton(
              child: Text(
                'Xaritada Ko\'rish',
                style: TextStyle(color: Colors.green[900]),
              ),
              onPressed: () => _launchURL(url, context),
            ),
            TextButton(
              child: Text(
                'Yopish',
                style: TextStyle(color: Colors.redAccent),
              ),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  void _launchURL(String url, BuildContext context) async {
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Cannot launch the map.')),
      );
    }
  }

  void _makePhoneCall(String phoneNumber, BuildContext context) async {
    final Uri url = Uri(scheme: 'tel', path: phoneNumber);
    if (await canLaunch(url.toString())) {
      await launch(url.toString());
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Cannot make the phone call.')),
      );
    }
  }
}
