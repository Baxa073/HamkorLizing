import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:hamkoroffline/Login/employee_dashboard_page.dart';
import 'package:hamkoroffline/Login/login_screen.dart';
import 'package:hamkoroffline/Login/super_admin.dart';
import 'package:hamkoroffline/avtotransport/yengil_avtomobil_lizing_kalkulyator_page.dart';
import 'package:hamkoroffline/bino_inshoot/bino_kalkulyator.dart';
import 'package:hamkoroffline/cars/AllProductsPage.dart';
import 'package:hamkoroffline/dashbord_page.dart';
import 'package:hamkoroffline/maxsusTexnika/MaxsusTexnik_Kalkulyator.dart';
import 'package:hamkoroffline/models/leasing_services_page.dart';
import 'package:hamkoroffline/models/meyory_hujjat.dart';
import 'package:hamkoroffline/models/nav_bar.dart';
import 'package:hamkoroffline/pages/home_page.dart';
import 'package:hamkoroffline/qishloq/qishloq_kalkulyator.dart';
import 'package:hamkoroffline/uskunalar/uskunaKalkulyator.dart';


class LeasingOptionsPage extends StatelessWidget {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>(); // Define a GlobalKey for the Scaffold

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey, // Assign the GlobalKey to the Scaffold
      appBar: CustomNavBar(
        onDrawerIconPressed: () {
          _scaffoldKey.currentState?.openDrawer(); // Open the drawer using the GlobalKey
        },
      ),
      drawer: _buildDrawer(context), // Use the _buildDrawer method for the drawer content
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: buildLeasingOptions(context),
      ),
    );
  }

  Widget buildLeasingOptions(BuildContext context) {
    return ListView(
      children: [
        buildListTile(
            context,
            'Avtotransport',
            'assets/images/Truck_and_car.png',
            YengilAvtomobilLizingKalkulyatorPage()),
        buildListTile(
            context,
            'Maxsus texnikalar',
            'assets/images/spes.jpg',
            MaxsusKalkulyatorPage()),
        buildListTile(
            context,
            'Qishloq xo\'jalik texnikalari',
            'assets/images/Selxoz.png',
            QishloqKalkulyatorPage()),
        buildListTile(
            context,
            'Bino-inshootlar',
            'assets/images/bino.jpg',
            BinoKalkulyatorPage()),
        buildListTile(
            context,
            'Uskunalar',
            'assets/images/qurilma_1.jpg',
            UskunaKalkulyatorPage()),
      ],
    );
  }

  Widget buildListTile(BuildContext context, String title, String imagePath,
      Widget page) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => page),
        );
      },
      child: Container(
        height: 100.0,
        margin: const EdgeInsets.symmetric(vertical: 10.0),
        padding: const EdgeInsets.all(10.0),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.5),
              spreadRadius: 2,
              blurRadius: 5,
              offset: Offset(0, 3),
            ),
          ],
        ),
        child: Row(
          children: [
            Expanded(
              child: Text(
                title,
                style: const TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 20.0,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            Image.asset(imagePath, width: 100.0, semanticLabel: title),
          ],
        ),
      ),
    );
  }

  // Method to build the drawer
  Widget _buildDrawer(BuildContext context) {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: <Widget>[
          DrawerHeader(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Color(0xFF1B5E20), Color(0xFF4CAF50)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
            child: Text(
              'Hamkor Lizing',
              style: TextStyle(
                color: Colors.white,
                fontSize: 24,
                fontWeight: FontWeight.bold,
                shadows: [
                  Shadow(
                    blurRadius: 10.0,
                    color: Colors.black45,
                    offset: Offset(2.0, 2.0),
                  ),
                ],
              ),
            ),
          ),
          _buildNavButton(
            context,
            title: 'Bosh sahifa',
            destination: HomePage(),
            icon: Icons.home,
          ),
          _buildNavButton(
            context,
            title: 'Barcha Mahsulotlar',
            destination: AllProductsPage(categoryTitle: 'Barcha Mahsulotlar'),
            icon: Icons.directions_car,
          ),
          _buildNavButton(
            context,
            title: 'Xizmatlar',
            destination: LeasingServicesPage(),
            icon: Icons.business_center,
          ),
          _buildNavButton(
            context,
            title: 'Lizing Kalkulyator',
            destination: LeasingOptionsPage(),
            icon: Icons.calculate,
          ),
          _buildNavButton(
            context,
            title: 'Me\'yoriy Hujjatlar',
            destination: MeyoriyHujjatlarPage(),
            icon: Icons.file_copy,
          ),
          if (FirebaseAuth.instance.currentUser != null)
            FutureBuilder<Widget>(
              future: _determineDestination(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: CircularProgressIndicator(),
                  );
                } else if (snapshot.hasError) {
                  return Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text('Error: ${snapshot.error}'),
                  );
                } else if (snapshot.hasData) {
                  return _buildNavButton(
                    context,
                    title: 'Shaxsiy Hisobim',
                    destination: snapshot.data!,
                    icon: Icons.account_circle,
                  );
                } else {
                  return Container();
                }
              },
            ),
          if (FirebaseAuth.instance.currentUser == null)
            _buildNavButton(
              context,
              title: 'Kirish',
              destination: LoginScreen(),
              icon: Icons.login,
            ),
        ],
      ),
    );
  }

  Widget _buildNavButton(BuildContext context, {required String title, required Widget destination, required IconData icon}) {
    return ListTile(
      leading: Icon(icon, color: Colors.green),
      title: Text(
        title,
        style: TextStyle(
          color: Colors.green.shade800,
          fontWeight: FontWeight.bold,
        ),
      ),
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => destination),
        );
      },
    );
  }

  Future<Widget> _determineDestination() async {
    User? currentUser = FirebaseAuth.instance.currentUser;

    if (currentUser == null) {
      return LoginScreen();
    }

    String email = currentUser.email?.toLowerCase() ?? '';
    final roleRef = FirebaseDatabase.instance
        .ref()
        .child('profiles/${currentUser.uid}/role');

    final DatabaseEvent event = await roleRef.once();
    final String role = event.snapshot.value as String? ?? '';

    if (role == 'SuperAdmin' || email == 'buxorovbahodir11@gmail.com') {
      return SuperAdminProfilePage();
    } else if (role == 'Bosh Direktor') {
      return AdminDashboardPage();
    } else {
      return EmployeeDashboardPage(user: currentUser);
    }
  }
}
