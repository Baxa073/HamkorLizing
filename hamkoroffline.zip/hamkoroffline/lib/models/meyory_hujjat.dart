import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:hamkoroffline/Login/login_screen.dart';
import 'package:hamkoroffline/cars/AllProductsPage.dart';
import 'package:hamkoroffline/models/leasing_services_page.dart';
import 'package:hamkoroffline/pages/home_page.dart';
import 'package:responsive_builder/responsive_builder.dart';
import 'package:path_provider/path_provider.dart';
import 'package:flutter/services.dart';
import 'dart:io';
import 'dart:html' as html; // Only available for web

import 'leasing_calculator.dart';
import 'nav_bar.dart';

class MeyoriyHujjatlarPage extends StatelessWidget {
  final GlobalKey<ScaffoldState> _scaffoldKey =
  GlobalKey<ScaffoldState>(); // Define a GlobalKey for the Scaffold

  final List<Map<String, String>> documents = [
    {
      'title': 'Lizing to\'g\'risida qonun',
      'description': 'Lizing haqida batafsil ma\'lumot beruvchi hujjat.',
      'url': 'https://lex.uz/ru/docs/-85259'
    },
    {
      'title': 'Fuqarolik kodeksi',
      'description':
      'Fuqarolik kodeksi haqida batafsil ma\'lumot beruvchi hujjat.',
      'url': 'https://lex.uz/acts/111189'
    },
    {
      'title': 'Ijara to\'g\'risidagi qonun',
      'description': 'Ijara haqida batafsil ma\'lumot beruvchi hujjat.',
      'url': 'https://lex.uz/acts/112328'
    },
    {
      'title': 'Garov toʻgʻrisidagi qonun',
      'description': 'Garov haqida batafsil ma\'lumot beruvchi hujjat.',
      'url': 'https://lex.uz/docs/59914?ONDATE=21.04.2021'
    },
    {
      'title': 'Toʻlovga layoqatsizlik toʻgʻrisidagi qonun',
      'description':
      'To\'lovga layoqatsizlik haqida batafsil ma\'lumot beruvchi hujjat.',
      'url': 'https://lex.uz/uz/docs/5957612'
    },
    {
      'title': 'Ijara buxgalteriya hisobi',
      'description': 'Ijara buxgalteriyasi haqida hujjat.',
      'url': 'https://lex.uz/docs/-1484335?ONDATE=11.06.2009'
    },
    {
      'title': 'Soliq kodeksi',
      'description': 'Soliq kodeksi bo\'yicha ma\'lumotlar.',
      'url': 'https://lex.uz/docs/-4674902?ONDATE=08.02.2024'
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      appBar: CustomNavBar(
        onDrawerIconPressed: () {
          _scaffoldKey.currentState?.openDrawer();
        },
      ),
      drawer: _buildDrawer(context),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ResponsiveBuilder(
          builder: (context, sizingInformation) {
            // Determine number of columns based on screen size
            int crossAxisCount = 1;
            double childAspectRatio = 1.5;

            if (sizingInformation.isMobile) {
              crossAxisCount = 1;
              childAspectRatio = 1.5;
            } else if (sizingInformation.isTablet) {
              crossAxisCount = 2;
              childAspectRatio = 1.8;
            } else {
              crossAxisCount = 3;
              childAspectRatio = 2.0;
            }

            return GridView.builder(
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: crossAxisCount,
                crossAxisSpacing: 16.0,
                mainAxisSpacing: 16.0,
                childAspectRatio: childAspectRatio,
              ),
              itemCount: documents.length,
              itemBuilder: (context, index) {
                return _buildDocumentCard(
                  context,
                  title: documents[index]['title']!,
                  description: documents[index]['description']!,
                  fileName: documents[index]['url']!,
                );
              },
            );
          },
        ),
      ),
    );
  }

  Widget _buildDocumentCard(BuildContext context,
      {required String title,
        required String description,
        required String fileName}) {
    return GestureDetector(
      onTap: () => _downloadFile(context, fileName),
      child: AnimatedContainer(
        duration: Duration(milliseconds: 300),
        curve: Curves.easeInOut,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.white, Colors.green[50]!],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(15),
          boxShadow: [
            BoxShadow(
              color: Colors.greenAccent.withOpacity(0.2),
              blurRadius: 10,
              spreadRadius: 5,
            ),
          ],
        ),
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(
              Icons.description,
              color: Colors.green,
              size: 50.0,
            ),
            SizedBox(height: 10),
            Text(
              title,
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
                color: Colors.green[900],
              ),
            ),
            SizedBox(height: 10),
            Text(
              description,
              style: TextStyle(
                fontSize: 16,
                color: Colors.green[700],
              ),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
            SizedBox(height: 10),
            // Wrap Button inside a Column for proper layout
            Column(
              children: [
                ElevatedButton.icon(
                  onPressed: () => _downloadFile(context, fileName),
                  icon: Icon(Icons.file_copy, color: Colors.white),
                  label: Text('Batafsil', style: TextStyle(color: Colors.white)),
                  style: ElevatedButton.styleFrom(
                    foregroundColor: Colors.white,
                    backgroundColor: Colors.green[700],
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    elevation: 5,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _downloadFile(BuildContext context, String fileName) async {
    try {
      if (kIsWeb) {
        _downloadFileWeb(fileName);
      } else {
        final ByteData data = await rootBundle.load(fileName);
        final String dir = (await getApplicationDocumentsDirectory()).path;
        final File file = File('$dir/${fileName.split('/').last}');
        await file.writeAsBytes(data.buffer.asUint8List());
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Fayl muvaffaqiyatli yuklandi: ${fileName.split('/').last}')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Fayl yuklashda xatolik: $e')),
      );
    }
  }

  void _downloadFileWeb(String fileName) {
    final url = fileName;
    final anchor = html.AnchorElement(href: url)
      ..setAttribute('download', url.split('/').last)
      ..click();
  }

  Widget _buildDrawer(BuildContext context) {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: <Widget>[
          DrawerHeader(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Color(0xFF1B5E20), Color(0xFF4CAF50)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
            child: Text(
              'Hamkor Lizing',
              style: TextStyle(
                color: Colors.white,
                fontSize: 24,
                fontWeight: FontWeight.bold,
                shadows: [
                  Shadow(
                    blurRadius: 10.0,
                    color: Colors.black45,
                    offset: Offset(2.0, 2.0),
                  ),
                ],
              ),
            ),
          ),
          ListTile(
            leading: Icon(Icons.home, color: Colors.green),
            title: Text('Bosh sahifa',
                style: TextStyle(
                    color: Colors.green.shade800, fontWeight: FontWeight.bold)),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => HomePage()),
              );
            },
          ),
          ListTile(
            leading: Icon(Icons.directions_car, color: Colors.green),
            title: Text('Barcha Mahsulotlar',
                style: TextStyle(
                    color: Colors.green.shade800, fontWeight: FontWeight.bold)),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) =>
                        AllProductsPage(categoryTitle: 'Barcha Mahsulotlar')),
              );
            },
          ),
          ListTile(
            leading: Icon(Icons.business_center, color: Colors.green),
            title: Text('Xizmatlar',
                style: TextStyle(
                    color: Colors.green.shade800, fontWeight: FontWeight.bold)),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => LeasingServicesPage()),
              );
            },
          ),
          ListTile(
            leading: Icon(Icons.calculate, color: Colors.green),
            title: Text('Lizing Kalkulyator',
                style: TextStyle(
                    color: Colors.green.shade800, fontWeight: FontWeight.bold)),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => LeasingOptionsPage()),
              );
            },
          ),
          ListTile(
            leading: Icon(Icons.file_copy, color: Colors.green),
            title: Text('Me\'yoriy Hujjatlar',
                style: TextStyle(
                    color: Colors.green.shade800, fontWeight: FontWeight.bold)),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => MeyoriyHujjatlarPage()),
              );
            },
          ),
          ListTile(
            leading: Icon(Icons.login, color: Colors.green),
            title: Text('Kirish',
                style: TextStyle(
                    color: Colors.green.shade800, fontWeight: FontWeight.bold)),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => LoginScreen()),
              );
            },
          ),
        ],
      ),
    );
  }
}
