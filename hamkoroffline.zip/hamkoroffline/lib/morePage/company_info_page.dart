import 'package:flutter/material.dart';

class CompanyInfoPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title:
            Text('Kompaniya haqida', style: TextStyle(fontFamily: 'Poppins')),
        backgroundColor: Colors.green,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Center(
                child: Image.asset('assets/images/Logo__1.png',
                    width: 300, height: 100),
              ),
              SizedBox(height: 20.0),
              Text(
                'Hamkor Lizing',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 28.0,
                  fontWeight: FontWeight.bold,
                  color: Colors.green,
                ),
              ),
              SizedBox(height: 20.0),
              Row(
                children: [
                  Icon(Icons.info, color: Colors.green),
                  SizedBox(width: 10.0),
                  Expanded(
                    child: Text(
                      'Hamkor Lizing OOO "Hamkor Maz Lizing" - bu Oʻzbekistonning yetakchi lizing kompaniyalaridan biri bo‘lib, turli xil transport vositalari va korxona uskunalarini lizingga taqdim etadi.',
                      style: TextStyle(
                        fontFamily: 'Poppins',
                        fontSize: 16.0,
                        color: Colors.black87,
                      ),
                    ),
                  ),
                ],
              ),
              SizedBox(height: 20.0),
              Text(
                'Bizning xizmatlarimiz:',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 20.0,
                  fontWeight: FontWeight.bold,
                  color: Colors.green,
                ),
              ),
              SizedBox(height: 10.0),
              buildServiceItem(
                  Icons.directions_car, 'Yengil avtomobillar lizingi'),
              buildServiceItem(Icons.local_shipping, 'Yuk transporti lizingi'),
              buildServiceItem(Icons.build, 'Korxona uskunalari lizingi'),
              buildServiceItem(Icons.monetization_on,
                  'Moliyaviy maslahatlar va ko‘rsatmalar'),
              SizedBox(height: 20.0),
              Text(
                'Aloqa ma\'lumotlari:',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 20.0,
                  fontWeight: FontWeight.bold,
                  color: Colors.green,
                ),
              ),
              SizedBox(height: 10.0),
              buildContactItem(
                  Icons.location_on, 'Manzil: O\'zbekiston, Toshkent sh.'),
              buildContactItem(Icons.phone, 'Telefon: +998 71 123 45 67'),
              buildContactItem(Icons.email, 'Email: info@hamkorlizing.uz'),
              SizedBox(height: 20.0),
              Text(
                'Yuridik shaxslar uchun mol-mulklarni lizingga berish xizmati',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 20.0,
                  fontWeight: FontWeight.bold,
                  color: Colors.green,
                ),
              ),
              SizedBox(height: 10.0),
              Text(
                'Shartlari:',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 18.0,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),
              SizedBox(height: 10.0),
              Text(
                '• Lizingga oluvchi – Yuridik shaxslar;\n• Lizing obyektining qiymati lizing garov mulki hisoblanadi;\n• Lizing muddati 12 oydan 60 oygacha;\n• Lizing summasi 100 000 000 dan 10 000 000 000 so\'mgacha;\n• Lizingga oluvchi tomonidan eng kamida obyekt qiymatining 30 foizdan kam bo\'lmagan miqdorda boshlang\'ich to\'lov amalga oshiriladi.',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 16.0,
                  color: Colors.black87,
                ),
              ),
              SizedBox(height: 20.0),
              Text(
                'Yakka tartibdagi tadbirkorlar va jismoniy shaxslar uchun mol-mulklarni moliyaviy va operativ ijaraga berish xizmati',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 20.0,
                  fontWeight: FontWeight.bold,
                  color: Colors.green,
                ),
              ),
              SizedBox(height: 10.0),
              Text(
                'Shartlari:',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 18.0,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),
              SizedBox(height: 10.0),
              Text(
                '• Moliyaviy ijara oluvchi – Yakka tartibdagi tadbirkorlar yoki jismoniy shaxslar;\n• Moliyaviy ijara obyektining qiymati garov mulki hisoblanadi;\n• Moliyaviy ijara muddati 12 oydan ortiq muddatga ega;\n• Moliyaviy ijara summasi lizing garov qiymatining 30 foizidan kam bo\'lmagan miqdorda boshlang\'ich to\'lovni amalga oshiriladi.',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 16.0,
                  color: Colors.black87,
                ),
              ),
              SizedBox(height: 20.0),
              Center(
                child: Text(
                  'Eng qulay shartlar bizda!',
                  style: TextStyle(
                    fontFamily: 'Poppins',
                    fontSize: 20.0,
                    fontWeight: FontWeight.bold,
                    color: Colors.red,
                  ),
                ),
              ),
              SizedBox(height: 10.0),
            ],
          ),
        ),
      ),
    );
  }

  Widget buildServiceItem(IconData icon, String text) {
    return Row(
      children: [
        Icon(icon, color: Colors.green),
        SizedBox(width: 10.0),
        Expanded(
          child: Text(
            text,
            style: TextStyle(
              fontFamily: 'Poppins',
              fontSize: 16.0,
              color: Colors.black87,
            ),
          ),
        ),
      ],
    );
  }

  Widget buildContactItem(IconData icon, String text) {
    return Row(
      children: [
        Icon(icon, color: Colors.green),
        SizedBox(width: 10.0),
        Expanded(
          child: Text(
            text,
            style: TextStyle(
              fontFamily: 'Poppins',
              fontSize: 16.0,
              color: Colors.black87,
            ),
          ),
        ),
      ],
    );
  }
}
