import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:hamkoroffline/models/leasing_calculator.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:hamkoroffline/cars/item.dart';
import 'dart:html' as html;

class ItemDetailPage extends StatefulWidget {
  final Item item;

  const ItemDetailPage({Key? key, required this.item}) : super(key: key);

  @override
  _ItemDetailPageState createState() => _ItemDetailPageState();
}

class _ItemDetailPageState extends State<ItemDetailPage> {
  int _selectedImageIndex = 0; // For keeping track of the selected image

  @override
  Widget build(BuildContext context) {
    final NumberFormat currencyFormat = NumberFormat.currency(
      locale: 'uz_UZ',
      symbol: widget.item.currency, // Use the item's currency
      decimalDigits: 0,
    );

    final screenWidth = MediaQuery.of(context).size.width;
    final isMobile = screenWidth < 600;

    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 2,
        iconTheme: IconThemeData(color: Colors.black),
        title: Text(
          widget.item.name,
          style: TextStyle(
            color: Colors.black,
            fontWeight: FontWeight.bold,
            fontSize: 24,
          ),
        ),
        centerTitle: true,
        actions: [
          IconButton(
            icon: Icon(Icons.share, color: Colors.black),
            onPressed: () {
              _shareItemOnWeb(context, widget.item);
            },
          ),
        ],
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.white, Colors.grey[200]!],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                isMobile
                    ? _buildMobileLayout(currencyFormat)
                    : _buildDesktopLayout(currencyFormat),
                SizedBox(height: 20),
                _buildLizingCalculatorButton(context),
                SizedBox(height: 20),
                _buildSocialButtons(),
              ],
            ),
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          _makePhoneCall('+998990443322');
        },
        label: Text('Qo\'ng\'iroq qilish'),
        icon: Icon(Icons.phone),
        backgroundColor: Colors.green,
        elevation: 10,
      ),
    );
  }

  Widget _buildMobileLayout(NumberFormat currencyFormat) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildMainImage(),
        SizedBox(height: 16),
        _buildThumbnailImages(),
        SizedBox(height: 16),
        _buildDetailSection(currencyFormat),
      ],
    );
  }

  Widget _buildDesktopLayout(NumberFormat currencyFormat) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          flex: 3,
          child: Column(
            children: [
              _buildMainImage(),
              SizedBox(height: 16),
              _buildThumbnailImages(),
            ],
          ),
        ),
        SizedBox(width: 24),
        Expanded(
          flex: 4,
          child: _buildDetailSection(currencyFormat),
        ),
      ],
    );
  }

  Widget _buildMainImage() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(20),
      child: Image.network(
        widget.item.imagePaths[_selectedImageIndex],
        fit: BoxFit.contain,
        width: double.infinity,
        height: 300,
        errorBuilder: (context, error, stackTrace) {
          return Center(
            child: Icon(
              Icons.broken_image,
              color: Colors.grey,
              size: 50,
            ),
          );
        },
        loadingBuilder: (context, child, loadingProgress) {
          if (loadingProgress == null) {
            return child;
          }
          return Center(
            child: CircularProgressIndicator(),
          );
        },
      ),
    );
  }

  Widget _buildThumbnailImages() {
    return Container(
      height: 80,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: widget.item.imagePaths.length,
        itemBuilder: (context, index) {
          return GestureDetector(
            onTap: () {
              setState(() {
                _selectedImageIndex = index;
              });
            },
            child: Container(
              margin: EdgeInsets.symmetric(horizontal: 4.0),
              padding: EdgeInsets.all(4.0),
              decoration: BoxDecoration(
                border: Border.all(
                  color: _selectedImageIndex == index
                      ? Colors.green
                      : Colors.transparent,
                  width: 2.0,
                ),
                borderRadius: BorderRadius.circular(12.0),
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.network(
                  widget.item.imagePaths[index],
                  fit: BoxFit.cover,
                  width: 80,
                  height: 80,
                  errorBuilder: (context, error, stackTrace) {
                    return Icon(Icons.broken_image, size: 50, color: Colors.grey);
                  },
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildDetailSection(NumberFormat currencyFormat) {
    return Container(
      padding: EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black12,
            blurRadius: 15,
            offset: Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            widget.item.description,
            style: TextStyle(
              fontSize: 18,
              height: 1.6,
              color: Colors.grey[800],
            ),
          ),
          SizedBox(height: 20),
          Divider(color: Colors.grey[300]),
          Text(
            'Detallar',
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: Colors.black87,
            ),
          ),
          SizedBox(height: 16),
          _buildDetailRow(Icons.directions_car, 'Tip kuzova', widget.item.type),
          _buildDetailRow(Icons.directions_car_filled, 'Marka', widget.item.name),
          _buildDetailRow(Icons.local_gas_station, 'Tip avtomobil', widget.item.fuelType),
          _buildDetailRow(Icons.calendar_today, 'Yil', widget.item.year),
          _buildDetailRow(Icons.engineering, 'Dvigatel quvvati', widget.item.enginePower),
          SizedBox(height: 16),
          Text(
            'Narxi: ${currencyFormat.format(widget.item.price)}', // Removed the additional currency symbol
            style: TextStyle(
              fontSize: 26,
              fontWeight: FontWeight.bold,
              color: Colors.redAccent,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDetailRow(IconData icon, String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: Colors.green, size: 24),
          SizedBox(width: 10),
          Flexible(
            child: Text(
              '$label: ',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.black87,
              ),
            ),
          ),
          SizedBox(width: 8),
          Expanded(
            child: Text(
              value,
              style: TextStyle(
                fontSize: 18,
                color: Colors.grey[600],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLizingCalculatorButton(BuildContext context) {
    return Center(
      child: ElevatedButton.icon(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => LeasingOptionsPage()), // Make sure LeasingOptionsPage is imported
          );
        },
        icon: Icon(Icons.calculate),
        label: Text("Lizing Kalkulyator"),
        style: ElevatedButton.styleFrom(
          foregroundColor: Colors.white,
          backgroundColor: Colors.green,
          padding: EdgeInsets.symmetric(horizontal: 20, vertical: 15),
          textStyle: TextStyle(fontSize: 18),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(30),
          ),
          elevation: 5,
        ),
      ),
    );
  }

  Widget _buildSocialButtons() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        _buildSocialIcon(Icons.telegram, Colors.blueAccent, 'https://t.me/HamkorLizingUz'),
      ],
    );
  }

  Widget _buildSocialIcon(IconData icon, Color color, String url) {
    return GestureDetector(
      onTap: () => _launchURL(url),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12.0),
        child: CircleAvatar(
          radius: 24,
          backgroundColor: Colors.white,
          child: Icon(
            icon,
            size: 28,
            color: color,
          ),
        ),
      ),
    );
  }

  void _launchURL(String url) async {
    final Uri _url = Uri.parse(url);
    if (!await launchUrl(_url)) {
      throw 'Could not launch $url';
    }
  }

  void _makePhoneCall(String phoneNumber) async {
    final Uri launchUri = Uri(
      scheme: 'tel',
      path: phoneNumber,
    );
    await launch(launchUri.toString());
  }
}

void _shareItemOnWeb(BuildContext context, Item item) {
  final String currentUrl = html.window.location.href;

  final String shareText = '''
${item.name}

${item.description}

Narxi: ${item.currency} ${item.price}

Link: $currentUrl
  ''';

  Clipboard.setData(ClipboardData(text: shareText)).then((_) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text("Ma'lumot va link nusxalandi. Endi uni ulashingiz mumkin."),
        behavior: SnackBarBehavior.floating,
        margin: EdgeInsets.all(16.0),
      ),
    );
  });
}
